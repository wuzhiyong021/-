//
//  NewsCell.m
//  TestNews
//
//  Created by qianfeng on 15/10/10.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "NewsCell.h"
#import "UIImageView+WebCache.h"
#import "Masonry.h"


@implementation NewsCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)configModel:(NewsModel *)model{
    if (model.img.length > 10) {
        self.newsImage.hidden = NO;
        [self.newsImage sd_setImageWithURL:[NSURL URLWithString:model.img]];
        
//        CGRect frame= self.newsTitleLabel.frame;
//        frame.origin.x = 100;
//        frame.size.width = 266;
//        self.newsTitleLabel.frame =frame;
        
        [self.newsTitleLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.newsImage.mas_right).offset(10);
        }];
        
        self.newsTitleLabel.font = [UIFont systemFontOfSize:16];
        self.newsTitleLabel.text = model.title;
        self.newsTitleLabel.numberOfLines = 0;
        
        
//        CGRect imageFrame = self.likeCoumtImage.frame;
//        imageFrame.origin.x = 100;
//        self.likeCoumtImage.frame =imageFrame;
        [self.likeCoumtImage mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.newsImage.mas_right).offset(10);
        }];
        
        if (model.hot < 200) {
            self.likeCoumtImage.image = [UIImage imageNamed:@"hotA"];
        }else if (model.hot < 1000){
            self.likeCoumtImage.image = [UIImage imageNamed:@"hotB"];
        }else{
            self.likeCoumtImage.image = [UIImage imageNamed:@"hotC"];
        }
        
//        CGRect likeframe= self.countLabel.frame;
//        likeframe.origin.x = 140;
//        
//        self.countLabel.frame =likeframe;
        
        self.countLabel.text =[NSString stringWithFormat:@"%ld",model.hot];
        self.sourceLabel.text = model.source;
    }else {
        
        self.newsImage.hidden = YES;
//        CGRect frame= self.newsTitleLabel.frame;
//        frame.origin.x = 10;
//        frame.size.width = 350;
//        self.newsTitleLabel.frame =frame;
        [self.newsTitleLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView).offset(10);
        }];
        
        self.newsTitleLabel.font = [UIFont systemFontOfSize:16];
        self.newsTitleLabel.text = model.title;
        self.newsTitleLabel.numberOfLines = 0;
        
//        CGRect imageFrame = self.likeCoumtImage.frame;
//        imageFrame.origin.x = 10;
//        self.likeCoumtImage.frame =imageFrame;
        [self.likeCoumtImage mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView).offset(10);
        }];

        
        if (model.hot < 200) {
            self.likeCoumtImage.image = [UIImage imageNamed:@"hotA"];
        }else if (model.hot < 1000){
            self.likeCoumtImage.image = [UIImage imageNamed:@"hotB"];
        }else{
            self.likeCoumtImage.image = [UIImage imageNamed:@"hotC"];
        }
        
//        CGRect likeframe= self.countLabel.frame;
//        likeframe.origin.x = 50;
//        self.countLabel.frame =likeframe;
       
        
        self.countLabel.text =[NSString stringWithFormat:@"%ld",model.hot];
        self.sourceLabel.text = model.source;
    }
    
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
