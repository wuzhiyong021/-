//
//  ShopCell.h
//  TestNews
//
//  Created by qianfeng on 15/10/18.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShopModel.h"

@interface ShopCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@property (weak, nonatomic) IBOutlet UIImageView *topImageView;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;


- (void)configModel:(ShopModel *)model;

@end
