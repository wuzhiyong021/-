//
//  SearchCollectionViewCell.h
//  TestNews
//
//  Created by qianfeng on 15/10/18.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShopModel.h"


@protocol SearchCollectionViewCellDelegate  <NSObject>

- (void)textFeildName:(NSString *)name;

@end

@interface SearchCollectionViewCell : UICollectionViewCell
- (IBAction)selectName:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *nameBtn;

- (void)configModel:(ShopModel *)model;


@property (nonatomic,weak)id<SearchCollectionViewCellDelegate> delegate;

@end
