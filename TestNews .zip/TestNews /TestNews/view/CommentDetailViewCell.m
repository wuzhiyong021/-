//
//  CommentDetailViewCell.m
//  TestNews
//
//  Created by qianfeng on 15/10/24.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "CommentDetailViewCell.h"
#import "Masonry.h"

@implementation CommentDetailViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)configModel:(CommentModel *)model{
    self.nickLabel.text = model.nickName;
    self.contentLabel.text = model.content;
    
}


- (CGFloat)heightWithModel:(CommentModel *)model{
    CGFloat descH= [model.content boundingRectWithSize:CGSizeMake(self.contentLabel.bounds.size.width, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]} context:nil].size.height;
    return 36+descH;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
