//
//  TaskCell.m
//  TestNews
//
//  Created by qianfeng on 15/10/17.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "TaskCell.h"

@implementation TaskCell

- (void)awakeFromNib {
    // Initialization code
}


- (void)setModel:(TaskModel *)model{
    self.taskTitleLabel.text = model.title;
    self.awardLabel.text =[NSString stringWithFormat:@"%ld",model.awardCount];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
