//
//  DiscoveryHeadView.m
//  TestNews
//
//  Created by qianfeng on 15/10/13.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "DiscoveryHeadView.h"
#import "Masonry.h"
#import "UIImageView+WebCache.h"


@implementation DiscoveryHeadView
{
    UIImageView *_bigImageView;
    UIImageView *_smallImageView;
    UILabel *_countLabel;
    UILabel *_descLabel;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        _bigImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, 140)];
        [self addSubview:_bigImageView];
        
        _smallImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10,100,50, 50)];
        [self addSubview:_smallImageView];
        
        _countLabel = [[UILabel alloc] initWithFrame:CGRectMake(65, 140, 100, 20)];
        _countLabel.font = [UIFont systemFontOfSize:14];
        [self addSubview:_countLabel];
        
       _descLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 160, self.bounds.size.width *(355/375.0f), 60)];
        _descLabel.font = [UIFont systemFontOfSize:15];
        _descLabel.numberOfLines = 0;
        [self addSubview:_descLabel];
        
        UIView *grayView = [[UIView alloc] initWithFrame:CGRectMake(0, 219, self.bounds.size.width, 1)];
        [self addSubview:grayView];
        grayView.backgroundColor = [UIColor grayColor];
        grayView.alpha = 0.3;
        
    }
    return self;
}

- (void)setModel:(NewsModel *)model{
    [_bigImageView sd_setImageWithURL:[NSURL URLWithString:model.bigimg]];
    [_smallImageView sd_setImageWithURL:[NSURL URLWithString:model.img]];
    _countLabel.text = [NSString stringWithFormat:@"订阅:%ld",model.hot];
    _descLabel.text =model.desc;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
