//
//  NewsCell.h
//  TestNews
//
//  Created by qianfeng on 15/10/10.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsModel.h"

@interface NewsCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *newsImage;
@property (weak, nonatomic) IBOutlet UIImageView *likeCoumtImage;

@property (weak, nonatomic) IBOutlet UILabel *newsTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *countLabel;
@property (weak, nonatomic) IBOutlet UILabel *sourceLabel;

- (void)configModel:(NewsModel *)model;

@end
