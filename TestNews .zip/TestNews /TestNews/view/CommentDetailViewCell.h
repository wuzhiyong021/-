//
//  CommentDetailViewCell.h
//  TestNews
//
//  Created by qianfeng on 15/10/24.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommentModel.h"

@interface CommentDetailViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nickLabel;

@property (weak, nonatomic) IBOutlet UILabel *contentLabel;


- (void)configModel:(CommentModel *)model;
- (CGFloat)heightWithModel:(CommentModel *)model;

@end
