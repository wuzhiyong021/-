//
//  SearchResultViewCell.h
//  TestNews
//
//  Created by qianfeng on 15/10/19.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsModel.h"

@interface SearchResultViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *sourceLabel;
@property (weak, nonatomic) IBOutlet UILabel *hotLabel;


@property (nonatomic,strong)NewsModel *model;

@end
