//
//  BigImageViewCell.m
//  TestNews
//
//  Created by qianfeng on 15/10/10.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "BigImageViewCell.h"
#import "UIImageView+WebCache.h"

@implementation BigImageViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)configModel:(NewsModel *)model{
    [self.bigImage sd_setImageWithURL:[NSURL URLWithString:model.img]];
    self.titleLabel.text = model.title;
    
}

- (void)tipNameWith:(NSString *)str{
    self.tipLabel.text = str;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
