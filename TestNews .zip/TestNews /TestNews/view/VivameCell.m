//
//  VivameCell.m
//  TestNews
//
//  Created by qianfeng on 15/10/9.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "VivameCell.h"
#import "UIImageView+WebCache.h"
#import "Masonry.h"


#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;
@implementation VivameCell

- (void)awakeFromNib {
    // Initialization code
    
}


- (void)configModel:(VivameModel *)model{
    
    WS(ws);
    self.model = model;
    
    //头像
    self.headIcon.layer.cornerRadius = 20;
    self.headIcon.layer.masksToBounds = YES;
    ;
    if (model.headIcon.length > 10) {
        [self.headIcon sd_setImageWithURL:[NSURL URLWithString:model.headIcon]];
    }else{
        self.headIcon.image = [UIImage imageNamed:@"NonGuestIcon"];
    }
    
    //称谓
    self.titleLabel.text = model.title;
    self.titleLabel.font = [UIFont systemFontOfSize:10];
    self.titleLabel.textColor = [UIColor greenColor];
    //昵称
    self.nickName.text = model.nickName;
    self.nickName.font = [UIFont systemFontOfSize:15];
    self.nickName.textColor = [UIColor blueColor];
    
    //评论

    CGFloat descH= [model.content boundingRectWithSize:CGSizeMake(ws.contentLabel.bounds.size.width, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]} context:nil].size.height;
    [self.contentLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(descH);
    }];

    self.contentLabel.text = model.content;
    self.contentLabel.font = [UIFont systemFontOfSize:16];
    self.contentLabel.numberOfLines = 0;

    //分享图片
    if (model.objectImg.length >10) {
        self.objectImg.hidden = NO;
        [self.objectImg sd_setImageWithURL:[NSURL URLWithString:model.objectImg]];
        [self.objectTitle mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(ws.objectImg.mas_right).offset(8);
            
        }];
    }else{
         self.objectImg.hidden = YES;
        [self.objectTitle mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(ws.contentView).offset(79);
            
        }];
//        x = 76;
//        width = 260;
    }
    

    
    //分享的标题
    self.objectTitle.font = [UIFont systemFontOfSize:16];
    self.objectTitle.numberOfLines = 0;
    self.objectTitle.text = model.objectTitle;
    
    
    //点赞数
    self.likeCountLabel.text =[NSString stringWithFormat:@"%ld人觉得很赞",model.likecount];
    self.likeCountLabel.textColor = [UIColor redColor];
    self.likeCountLabel.font = [UIFont systemFontOfSize:10];
}


- (CGFloat)heightWithModel:(VivameModel *)model{
    CGFloat descH= [model.content boundingRectWithSize:CGSizeMake(self.contentLabel.bounds.size.width, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]} context:nil].size.height;
    CGFloat y = 175;
    if (descH >= 40 ) {
        y = 135;
    }else{
        y = 175;
        descH = 0;
    }
    y += descH;
    return y;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)DetailBtn:(id)sender {
    [self.delegate GotoDetail:self.model];
}
@end
