//
//  HobbyHeaderView.h
//  TestNews
//
//  Created by qianfeng on 15/10/20.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsModel.h"

@protocol HobbyHeaderViewDelegate <NSObject>

- (void)didSelectHearder:(NewsModel *)model;

@end

@interface HobbyHeaderView : UIView<UIScrollViewDelegate>

@property (nonatomic,strong)NSArray *modelArray;
@property (nonatomic,weak)id<HobbyHeaderViewDelegate> delegate;

@end
