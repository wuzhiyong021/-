//
//  DiscoveryImageCell.m
//  TestNews
//
//  Created by qianfeng on 15/10/13.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "DiscoveryImageCell.h"
#import "UIImageView+WebCache.h"

@implementation DiscoveryImageCell

- (void)awakeFromNib {
    // Initialization code
}


- (void)setModel:(NewsModel *)model{
    _model = model;
    self.titleLabel.text = model.title;
    self.titleLabel.font = [UIFont systemFontOfSize:16];
    self.titleLabel.numberOfLines = 0;
    
    if (model.hot <1000) {
        self.likeImageView.image = [UIImage imageNamed:@"hotA"];
    }else{
        self.likeImageView.image = [UIImage imageNamed:@"hotC"];
    }
    
    self.sourceLabel.text = model.source;
    
   
    [self.bigImageView sd_setImageWithURL:[NSURL URLWithString:model.img]];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
