//
//  HobbyHeaderView.m
//  TestNews
//
//  Created by qianfeng on 15/10/20.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "HobbyHeaderView.h"
#import "AdView.h"
#import "UIImageView+WebCache.h"

@implementation HobbyHeaderView
{
    UIScrollView *_scrollView;
    UILabel *_nameLabel;
    UIImage *_imageView;
    UIPageControl *_pageCtrl;
    
    AdView *adView;
}

//- (instancetype)initWithFrame:(CGRect)frame{
//    if (self = [super initWithFrame:frame]) {
//        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, 240)];
//        _scrollView.showsHorizontalScrollIndicator = NO;
//        [self addSubview:_scrollView];
//    }
//    return self;
//}


-(void)setModelArray:(NSArray *)modelArray{
//    _modelArray = modelArray;
//    for (int i = 0; i < modelArray.count; i++) {
//        NewsModel *model = modelArray[i];
//        UIImageView *scrollImageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.bounds.size.width*i, 0, self.bounds.size.width, 240)];
//        [_scrollView addSubview:scrollImageView];
//        [scrollImageView sd_setImageWithURL:[NSURL URLWithString:model.img]];
//        UITapGestureRecognizer *g = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickAction:)];
//        scrollImageView.userInteractionEnabled = YES;
//        [scrollImageView addGestureRecognizer:g];
//        
//        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 210, self.bounds.size.width, 30)];
//        view.backgroundColor = [UIColor blackColor];
//        view.alpha = 0.4;
//        [scrollImageView addSubview:view];
//        
//        
//        UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 215, 260, 20)];
//        nameLabel.textColor = [UIColor whiteColor];
//        nameLabel.text = model.title;
//        nameLabel.font = [UIFont systemFontOfSize:16];
//        [scrollImageView addSubview:nameLabel];
//    }
//    
//    _scrollView.delegate = self;
//    _scrollView.contentSize = CGSizeMake(self.bounds.size.width*modelArray.count, 200);
//    _scrollView.pagingEnabled = YES;
//    _scrollView.bounces = NO;
//    _pageCtrl = [[UIPageControl alloc] initWithFrame:CGRectMake(self.bounds.size.width*(310.0f/375.0f), 210, 60, 30)];
//    if (modelArray.count == 1) {
//        _pageCtrl.numberOfPages = 1;
//    }else{
//        _pageCtrl.numberOfPages = modelArray.count;
//    }
//    _pageCtrl.backgroundColor = [UIColor clearColor];
//    _pageCtrl.currentPage = 0;
//    _pageCtrl.currentPageIndicatorTintColor = [UIColor redColor];
//    _pageCtrl.tag = 100;
//    [_scrollView.superview addSubview:_pageCtrl];
//}
//
//
//#pragma mark - UIScrollView代理
//- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
//    
//    //获取滚动视图滚动到的当前页
//    NSInteger index= scrollView.contentOffset.x/scrollView.bounds.size.width;
//    //修改分页控件的当前页数
//    //分页控件
//    _pageCtrl.currentPage= index;
    self.backgroundColor = [UIColor whiteColor];

    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    
    
    //如果你的这个广告视图是添加到导航控制器子控制器的View上,请添加此句,否则可忽略此句
    

    adView = [AdView adScrollViewWithFrame:CGRectMake(0, 0, width, 240) modelArr:modelArray imagePropertyName:@"img" pageControlShowStyle:UIPageControlShowStyleRight];
    [adView setAdTitlePropertyName:@"title" withShowStyle:AdTitleShowStyleLeft];
    
    //    是否需要支持定时循环滚动，默认为YES
    //    adView.isNeedCycleRoll = YES;
    
    //    设置图片滚动时间,默认3s
    adView.adMoveTime = 4;
    
    //图片被点击后回调的方法
    __weak HobbyHeaderView *weakSelf = self;
    adView.callBackForModel = ^(NewsModel * model)
    {
        [weakSelf.delegate didSelectHearder:model];
    };
    [self addSubview:adView];

}


- (void)clickAction:(UITapGestureRecognizer *)g{
    NSInteger index = _scrollView.contentOffset.x/_scrollView.bounds.size.width;
    NewsModel *model = _modelArray[index];
    [self.delegate didSelectHearder:model];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
