//
//  ShopCell.m
//  TestNews
//
//  Created by qianfeng on 15/10/18.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "ShopCell.h"
#import "UIImageView+WebCache.h"

@implementation ShopCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)configModel:(ShopModel *)model{
        [self.topImageView sd_setImageWithURL:[NSURL URLWithString:model.img]];
    self.nameLabel.text = model.name;
    self.priceLabel.text = [NSString stringWithFormat:@"%ld",model.price];
   
    
}

@end
