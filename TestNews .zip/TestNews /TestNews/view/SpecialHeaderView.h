//
//  SpecialHeaderView.h
//  TestNews
//
//  Created by qianfeng on 15/10/20.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsModel.h"

@interface SpecialHeaderView : UIView


@property (nonatomic,strong)NewsModel *model;

@end
