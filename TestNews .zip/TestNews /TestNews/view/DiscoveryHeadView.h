//
//  DiscoveryHeadView.h
//  TestNews
//
//  Created by qianfeng on 15/10/13.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsModel.h"

@interface DiscoveryHeadView : UIView


@property (nonatomic,strong)NewsModel *model;

@end
