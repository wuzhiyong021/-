//
//  SpecialHeaderView.m
//  TestNews
//
//  Created by qianfeng on 15/10/20.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "SpecialHeaderView.h"
#import "UIImageView+WebCache.h"

@implementation SpecialHeaderView
{
    UIImageView *_imageView;
    UILabel *_titleLabel;
    UILabel *_descLabel;
}


- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, 200)];
        _imageView.backgroundColor = [UIColor redColor];
        [self addSubview:_imageView];
        UIView *blackView = [[UIView alloc] initWithFrame:CGRectMake(0, 170, self.bounds.size.width, 30)];
        blackView.backgroundColor = [UIColor blackColor];
        blackView.alpha = 0.5;
        [_imageView addSubview:blackView];
        
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 5, 260, 20)];
        _titleLabel.textColor = [UIColor whiteColor];
        [blackView addSubview:_titleLabel];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(5, 205, 20, 10)];
        label.textColor =[UIColor whiteColor];
        label.backgroundColor = [UIColor grayColor];
        label.text = @"摘要";
        label.font = [UIFont systemFontOfSize:10];
        [self addSubview:label];
        
        _descLabel = [[UILabel alloc] initWithFrame:CGRectMake(26, 205, self.bounds.size.width-36, 75)];

        _descLabel.numberOfLines = 0;
        [self addSubview:_descLabel];
        
        UIView *grayView = [[UIView alloc] initWithFrame:CGRectMake(0, 279, self.bounds.size.width, 1)];
        [self addSubview:grayView];
        grayView.backgroundColor = [UIColor grayColor];
        grayView.alpha = 0.3;
        
    }
    return self;
}


- (void)setModel:(NewsModel *)model{
    _model = model;
    [_imageView sd_setImageWithURL:[NSURL URLWithString:model.img]];
    _titleLabel.text = model.title;
    _descLabel.text = model.desc;
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
