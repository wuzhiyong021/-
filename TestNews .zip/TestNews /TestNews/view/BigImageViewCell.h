//
//  BigImageViewCell.h
//  TestNews
//
//  Created by qianfeng on 15/10/10.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsModel.h"

@interface BigImageViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *tipLabel;
@property (weak, nonatomic) IBOutlet UIImageView *bigImage;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

- (void)configModel:(NewsModel *)model;

- (void)tipNameWith:(NSString *)str;

@end
