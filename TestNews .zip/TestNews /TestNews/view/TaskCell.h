//
//  TaskCell.h
//  TestNews
//
//  Created by qianfeng on 15/10/17.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TaskModel.h"

@interface TaskCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *taskTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *awardLabel;

@property (nonatomic,strong)TaskModel *model;

@end
