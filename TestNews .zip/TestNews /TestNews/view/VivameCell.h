//
//  VivameCell.h
//  TestNews
//
//  Created by qianfeng on 15/10/9.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VivameModel.h"

@protocol VivameDelegate <NSObject>

- (void)GotoDetail:(VivameModel *)model;

@end

@interface VivameCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *headIcon;
@property (weak, nonatomic) IBOutlet UIButton *DetailBtn;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (weak, nonatomic) IBOutlet UILabel *nickName;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
- (IBAction)DetailBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *objectImg;
@property (weak, nonatomic) IBOutlet UILabel *objectTitle;
@property (weak, nonatomic) IBOutlet UILabel *likeCountLabel;

- (void)configModel:(VivameModel *)model;


- (CGFloat)heightWithModel:(VivameModel *)model;

@property (nonatomic,strong)VivameModel *model;

@property (nonatomic,weak)id<VivameDelegate> delegate;

@end
