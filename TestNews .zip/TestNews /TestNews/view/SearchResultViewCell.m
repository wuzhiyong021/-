//
//  SearchResultViewCell.m
//  TestNews
//
//  Created by qianfeng on 15/10/19.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "SearchResultViewCell.h"

@implementation SearchResultViewCell

- (void)awakeFromNib {
    // Initialization code
}


- (void)setModel:(NewsModel *)model{
    _model = model;
    self.titleLabel.text = model.title;
    self.hotLabel.text = [NSString stringWithFormat:@"%ld",model.hot];
    self.hotLabel.textColor = [UIColor redColor];
    self.sourceLabel.text = [NSString stringWithFormat:@"热度·%@",model.source];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
