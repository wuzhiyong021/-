//
//  SearchCollectionViewCell.m
//  TestNews
//
//  Created by qianfeng on 15/10/18.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "SearchCollectionViewCell.h"


@implementation SearchCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)configModel:(ShopModel *)model{
    [self.nameBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    if (model.type == 1) {
        [self.nameBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    }
    [self.nameBtn setTitle:model.name forState:UIControlStateNormal];
}

- (IBAction)selectName:(id)sender {
    [self.delegate textFeildName:[sender titleForState:UIControlStateNormal]];
}
@end
