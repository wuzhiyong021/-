//
//  DBManager.h
//  TestNews
//
//  Created by qianfeng on 15/10/20.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NewsModel.h"
#import "FMDatabase.h"

@interface DBManager : NSObject

+ (DBManager *)sharedManager;
//判断是否收藏
- (BOOL)isExists:(NSString *)url;

- (void)addModel:(NewsModel *)model;

- (void)delegateModel:(NSString *)url;

- (NSArray *)searchAllData;


@end
