//
//  DBManager.m
//  TestNews
//
//  Created by qianfeng on 15/10/20.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "DBManager.h"


@implementation DBManager
{
    FMDatabase *_dataBase;
}
+ (DBManager *)sharedManager{
    static DBManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^{
        if (manager == nil) {
            manager = [[DBManager alloc] init];
        }
    });
    return manager;
}

- (instancetype)init{
    if (self = [super init]) {
        [self createSQl];
    }
    return self;
}


- (void)createSQl{
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/newsFavorite.sqlite"];
//    NSLog(@"%@",path);
    _dataBase = [[FMDatabase alloc] initWithPath:path];
    BOOL isOpen = [_dataBase open];
    if (isOpen) {
        NSString *sql = @"create table if not exists newsFavorite(id integer primary key autoincrement, url varchar(255), headerImageUrl varchar(255), title varchar(255), hot integer, resource varchar(255), fileurl varchar(255))";
        BOOL flag = [_dataBase executeUpdate:sql];
        if (!flag) {
            NSLog(@"%@",_dataBase.lastErrorMessage);
        }
    }else{
        NSLog(@"数据库打开失败");
    }
    
}

- (BOOL)isExists:(NSString *)url{
    NSString *sql = @"select *from newsFavorite where url= ?";
    FMResultSet *rs = [_dataBase executeQuery:sql,url];
    if ([rs next]) {
        return YES;
    }else{
        return NO;
    }
}


- (void)addModel:(NewsModel *)model{
    NSString *sql = @"insert into newsFavorite(url,headerImageUrl, title, hot, resource, fileurl) values(?,?,?,?,?,?)";
    BOOL ret = [_dataBase executeUpdate:sql,model.url,model.img,model.title,@(model.hot),model.source,model.fileurl];
    if (!ret) {
        NSLog(@"%@",_dataBase.lastErrorMessage);
    }else{
        NSLog(@"添加成功");
    }
}


- (void)delegateModel:(NSString *)url{
    NSString *sql = @"delete from newsFavorite where url = ?";
    BOOL ret = [_dataBase executeUpdate:sql,url];
    if (!ret) {
        NSLog(@"%@",_dataBase.lastErrorMessage);
    }
}

- (NSArray *)searchAllData{
    NSString *sql = @"select * from newsFavorite";
    FMResultSet *rs = [_dataBase executeQuery:sql];
    NSMutableArray *array = [NSMutableArray array];
    
    while ([rs next]) {
        NewsModel *model = [[NewsModel alloc] init];
        model.url = [rs stringForColumn:@"url"];
        model.img = [rs stringForColumn:@"headerImageUrl"];
        model.title = [rs stringForColumn:@"title"];
        model.hot = [rs intForColumn:@"hot"];
        model.source =[rs stringForColumn:@"resource"];
        model.fileurl= [rs stringForColumn:@"fileurl"];
        [array addObject:model];
    }
    return array;
}

@end
