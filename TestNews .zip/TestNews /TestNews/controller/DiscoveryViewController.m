//
//  DiscoveryViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/5.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "DiscoveryViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "NewsModel.h"
#import "NewsCell.h"
#import "Masonry.h"
#import "DiscoveryImageCell.h"
#import "MJRefresh.h"
#import "DiscoveryHeadView.h"
#import "DetailViewController.h"

#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;
#define Kurl (@"http://interfacev5.vivame.cn/x1-interface-v5/json/newdatalist.json?platform=android&installversion=5.6.6.3&channelno=BDSCA2320480100&mid=7c2f435b4eb9c9267addf21979bc88c4&uid=11092073&sid=dcf250e2-b224-4356-bec5-5ae20263f22a&type=10&id=%ld&category=10&ot=%ld&nt=0")

@interface DiscoveryViewController ()<UITableViewDataSource,UITableViewDelegate,MJRefreshBaseViewDelegate>
{
    MJRefreshHeaderView *_headerView;
    MJRefreshFooterView *_footerview;
    BOOL _isLoading;
    DiscoveryHeadView *_headView;
}

@property (nonatomic,strong)UITableView *tbView;
@property (nonatomic,assign)NSInteger ot;
@property (nonatomic,assign)NSInteger pageId;
@property (nonatomic,strong)NSMutableArray *dataArray;
@property (nonatomic,assign)NSInteger oldTimestamp;
@property (nonatomic,strong)NewsModel *hearderModel;

@end

@implementation DiscoveryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dataArray = [NSMutableArray array];
    self.hearderModel = [[NewsModel alloc] init];
    self.ot = 0;
    _isLoading = NO;
    self.pageId = 21030;
    [self createTableView];
    [self createScrollViewBtn];
    [self downloadData];
    [self downloaderData];
}


- (void)downloadData{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSString *urlString = [NSString stringWithFormat:Kurl,self.pageId,self.ot];
    
    [manager GET:urlString parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        id  result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            NSDictionary *dict = result;
            NSDictionary *dataDict = dict[@"data"];
            for (NSDictionary *itemsDict in dataDict[@"headerlist"]) {
            for (NSDictionary *aDict in itemsDict[@"items"]) {
                [self.hearderModel setValuesForKeysWithDictionary:aDict];
            }
            self.hearderModel.hot =[ itemsDict[@"count"] integerValue];
            }
        _headView.model = self.hearderModel;
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"%@",error);
    }];
}

//创建tableView
- (void)createTableView{
    WS(ws);
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.tbView = [[UITableView alloc] init];
    self.tbView.delegate = self;
    self.tbView.dataSource = self;
    [ws.view addSubview:self.tbView];
    [self.tbView  mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(64);
        make.left.equalTo(ws.view);
        make.right.equalTo(ws.view);
        make.bottom.mas_equalTo(-49);
    }];
    
    _headerView = [MJRefreshHeaderView header];
    _headerView.delegate = self;
    _headerView.scrollView = self.tbView;
    
    _footerview = [MJRefreshFooterView footer];
    _footerview.delegate = self;
    _footerview.scrollView = self.tbView;
    
    _headView = [[DiscoveryHeadView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, 220)];
    self.tbView.tableHeaderView = _headView;
}

- (void)dealloc{
    _headerView.scrollView = nil;
    _footerview.scrollView = nil;
}

//下载数据
- (void)downloaderData{
    _isLoading = YES;
    
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSString *urlString = [NSString stringWithFormat:Kurl,self.pageId,self.ot];
    [manager GET:urlString parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (_ot == 0) {
            [_dataArray removeAllObjects];
        }
        //JSON解析
        id  result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if ([result isKindOfClass:[NSDictionary class]]) {
            if (_ot == 0) {
                [_dataArray removeAllObjects];
            }
            NSDictionary *dict = result;
            NSDictionary *dataDict = dict[@"data"];
            _oldTimestamp = [dataDict[@"oldTimestamp"] integerValue];
            //正文部分
            for (NSDictionary *itemsDict in dataDict[@"feedlist"]) {
                for (NSDictionary *aDict in itemsDict[@"items"]) {
                    NewsModel *model = [[NewsModel alloc] init];
                    [model setValuesForKeysWithDictionary:aDict];
                    [_dataArray addObject:model];
                }
            }
        }
        [self.tbView reloadData];
        _isLoading = NO;
        [_headerView endRefreshing];
        [_footerview endRefreshing];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"%@",error);
        _isLoading = NO;
        [_headerView endRefreshing];
        [_footerview endRefreshing];
    }];
}

//创建滑动视图
- (void)createScrollViewBtn{
    NSArray *titleArray = @[@"人民网",@"GQ男士网",@"新京报"];
    for (int i=0; i<titleArray.count; i++) {
        UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
        [btn setTitle:titleArray[i] forState:UIControlStateNormal];
        CGRect frame= CGRectMake(4+(90+10)*i, 8, 90, 30) ;
        btn.frame=frame;
        btn.tag = 900+i;
        if (i == 0) {
            [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            self.mySelect = 900;
        }else{
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        }
        [btn addTarget:self action:@selector(reload:) forControlEvents:UIControlEventTouchUpInside];
        _scrollView.userInteractionEnabled = YES;
        [_scrollView addSubview:btn];
    }
    _scrollView.contentSize=CGSizeMake(100*titleArray.count, 30);
}


//点击滑动视图的事件
- (void)reload:(UIButton *)btn{
    //改变按钮颜色
    UIButton *btn2 = (UIButton *)[_scrollView viewWithTag:self.mySelect];
    [btn2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIButton *btn1 = (UIButton *)[_scrollView viewWithTag:btn.tag];
    [btn1 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    self.mySelect = btn.tag;
    
    
    if (btn.tag == 900) {
        self.pageId = 21030;
    }else if (btn.tag == 901){
        self.pageId = 20001;
    }else if (btn.tag == 902){
        self.pageId = 21029;
    }
//    _headView.type = self.mySelect;
    [self downloadData];
    self.ot = 0;
    [self downloaderData];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark-UITableView代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NewsModel *model = _dataArray[indexPath.row];
    if (model.img.length > 10) {
        return 340;
    }
    return 80;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NewsModel *model = _dataArray[indexPath.row];
    if (model.img.length > 0) {
        static NSString *cellId = @"DiscoveryCellId";
        DiscoveryImageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"DiscoveryImageCell" owner:nil options:nil] lastObject];
        }
        cell.model = model;
        return cell;  
    }else{
        static NSString *cellId = @"newsCellId";
        NewsCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"NewsCell" owner:nil options:nil] lastObject];
        }
        [cell configModel:model];
        return cell;
    }
    return nil;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NewsModel *model = self.dataArray[indexPath.row];
    DetailViewController *dCtrl = [[DetailViewController alloc] init];
    dCtrl.model = model;
    self.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:dCtrl animated:YES];
    self.hidesBottomBarWhenPushed = NO;
}




#pragma mark- MJRefreshView代理
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView{
    if (_isLoading) {
        return;
    }
    if (_headerView == refreshView) {
        self.ot = 0;
        [self downloaderData];
    }if (_footerview == refreshView) {
        self.ot = self.oldTimestamp;
        [self downloaderData];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
