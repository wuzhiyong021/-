//
//  VivameDetailController.m
//  TestNews
//
//  Created by qianfeng on 15/10/14.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "VivameDetailController.h"
#import "AFHTTPRequestOperationManager.h"
#import "Masonry.h"

#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;

#define kUrl (@"http://interfacev5.vivame.cn/x1-interface-v5/json/getnews.json?platform=android&installversion=5.6.6.3&channelno=BDSCA2320480100&mid=7c2f435b4eb9c9267addf21979bc88c4&uid=11092073&sid=9c805b9e-6c60-4eef-a82a-629c04e8d9a5&type=1&id=%@&tagid=3&pushtype=0")

@interface VivameDetailController ()
{
    NSString *_urlString;
}



@end

@implementation VivameDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self createUIWebView];
    self.navigationController.navigationBar.hidden = YES;
    
    [self createNav];
}

- (void)createUIWebView{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager GET:[NSString stringWithFormat:kUrl,self.url] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        id result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dict =result;
            NSDictionary *dataDict = dict[@"data"];
            _urlString = dataDict[@"url"];
            [self createWebView];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"%@",error);
    }];
}


- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.hidden = NO;
}

- (void)createWebView{
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    
    
    UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width,self.view.bounds.size.height-64)];
    NSURL *url = [NSURL URLWithString:_urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [webView loadRequest:request];
    webView.scrollView.bounces = NO;
    [self.view addSubview:webView];
}

//状态栏
- (BOOL)prefersStatusBarHidden{
    return NO;
}

- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

//自定制导航
- (void)createNav{
    WS(ws);
    UIView *bgView = [[UIView alloc] init];
    bgView.backgroundColor = [UIColor blackColor];
    [ws.view addSubview:bgView];
    [bgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(ws.view);
        make.top.mas_equalTo(0);
        make.height.mas_equalTo(20);
    }];
    
    UIImageView *imageView = [[UIImageView alloc] init];
    //    imageView.image = [UIImage imageNamed:@"Discovery_fav_cell_line@2x"];
    imageView.backgroundColor = [UIColor blackColor];
    [ws.view addSubview:imageView];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(63);
        make.left.equalTo(ws.view);
        make.right.equalTo(ws.view);
        make.height.mas_equalTo(1);
    }];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[UIImage imageNamed:@"TopBackBtnNor"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    [ws.view addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(30);
        make.left.mas_equalTo(20);
        make.width.mas_equalTo(25);
        make.height.mas_equalTo(25);
    }];
    if(self.model){
        self.titleName = self.model.objectTitle;
    }
    
    UILabel *label = [[UILabel alloc] init];
    label.text = self.titleName;
    label.textColor = [UIColor blackColor];
    label.font = [UIFont systemFontOfSize:16];
    [ws.view addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(45);
        make.top.mas_equalTo(30);
        make.width.mas_equalTo(260);
        make.height.mas_equalTo(30);
    }];
    
}

//返回按钮
- (void)backAction:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
