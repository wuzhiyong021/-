//
//  ShopViewController.h
//  TestNews
//
//  Created by qianfeng on 15/10/17.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopViewController : UIViewController

@end
