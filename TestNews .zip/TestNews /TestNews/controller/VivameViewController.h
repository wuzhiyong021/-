//
//  VivameViewController.h
//  TestNews
//
//  Created by qianfeng on 15/10/8.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//


#import "ViewController.h"

@interface VivameViewController : ViewController

@end
