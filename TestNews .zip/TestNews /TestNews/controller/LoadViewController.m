//
//  LoadViewController.m
//  TestNews
//
//  Created by  on 11/11/2015.
//  Copyright © 2015 wuzhiyong. All rights reserved.
//

#import "LoadViewController.h"
#import "Masonry.h"
#import <AssetsLibrary/ALAsset.h>
#import <AssetsLibrary/ALAssetsLibrary.h>
#import <AssetsLibrary/ALAssetsGroup.h>
#import <AssetsLibrary/ALAssetRepresentation.h>

@interface LoadViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    UITextField *_nameFeild;
    UITextField *_secretFeild;
    UIButton *_iconBtn;
}
@end

@implementation LoadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self addNavTitle:@"登录"];
    [self createBtn];
}

- (void)createBtn{
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    //头像
    _iconBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:@"data"];
    UIImage *image = [UIImage imageWithData:data];
    [_iconBtn setBackgroundImage:image forState:UIControlStateNormal];
    [_iconBtn addTarget:self action:@selector(iocnChoose:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_iconBtn];
    CGFloat f = 0.39 * self.view.bounds.size.width;
    [_iconBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(80);
        make.left.equalTo(self.view.mas_left).mas_equalTo(f);
        make.width.mas_equalTo(100);
        make.height.mas_equalTo(100);
    }];
    _iconBtn.layer.cornerRadius = 50;
    _iconBtn.layer.masksToBounds = YES;
    
    //用户名
    UILabel *userName = [[UILabel alloc] init];
    userName.text = @"用户名:";
    userName.font = [UIFont systemFontOfSize:20];
    [self.view addSubview:userName];
    [userName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.top.mas_equalTo(200);
        make.width.mas_equalTo(80);
        make.height.mas_equalTo(40);
        
    }];
    
    //密码
    UILabel *userSecret = [[UILabel alloc] init];
    userSecret.text = @"密    码:";
    userSecret.font = [UIFont systemFontOfSize:20];
    [self.view addSubview:userSecret];
    [userSecret mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.top.mas_equalTo(240);
        make.width.mas_equalTo(80);
        make.height.mas_equalTo(40);
    }];
    
    _nameFeild = [[UITextField alloc] init];
    _nameFeild.placeholder = @"请输入用户名";
    _nameFeild.borderStyle = UITextBorderStyleRoundedRect;
    [self.view addSubview:_nameFeild];
    [_nameFeild mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(110);
        make.top.mas_equalTo(200);
        make.width.mas_equalTo(200);
        make.height.mas_equalTo(40);
    }];
    
    _secretFeild = [[UITextField alloc] init];
    _secretFeild.placeholder = @"请输入6-12位的密码";
    _secretFeild.borderStyle = UITextBorderStyleRoundedRect;
    [self.view addSubview:_secretFeild];
    [_secretFeild mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(110);
        make.top.mas_equalTo(240);
        make.width.mas_equalTo(200);
        make.height.mas_equalTo(40);
    }];
    
    UIButton *btn1 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn1.backgroundColor = [UIColor grayColor];
    [btn1 setTitle:@"注        册" forState:UIControlStateNormal];
    [btn1 setTintColor:[UIColor whiteColor]];
    [btn1 addTarget:self action:@selector(loadAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn1];
    [btn1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(60);
        make.top.mas_equalTo(300);
        make.width.mas_equalTo(80);
        make.height.mas_equalTo(40);
    }];
    
    UIButton *btn2 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn2.backgroundColor = [UIColor grayColor];
    [btn2 setTitle:@"登        录" forState:UIControlStateNormal];
    [btn2 setTintColor:[UIColor whiteColor]];
    [btn2 addTarget:self action:@selector(loadAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn2];
    [btn2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(200);
        make.top.mas_equalTo(300);
        make.width.mas_equalTo(80);
        make.height.mas_equalTo(40);
    }];
    
 }

- (void)loadAction:(UIButton *)btn{
    NSString *str = [NSString stringWithFormat:@"%@",_nameFeild.text];
    [[NSUserDefaults standardUserDefaults] setObject:str forKey:@"nameFeild"];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)iocnChoose:(UIButton *)btn{
    UIImagePickerController *imageCtrl = [[UIImagePickerController alloc] init];
    imageCtrl.delegate = self;
    imageCtrl.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:imageCtrl animated:YES completion:nil];
}

#pragma mark-UIImagePicker代理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    NSURL *imageURL = [info valueForKey:UIImagePickerControllerReferenceURL];
 
    ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *myasset)
 
    {
  
        ALAssetRepresentation *representation = [myasset defaultRepresentation];
     
        NSString *fileName = [representation filename];
      
   
        NSLog(@"fileName : %@",fileName);
    
    };
    
    ALAssetsLibrary* assetslibrary = [[ALAssetsLibrary alloc] init];
 
    [assetslibrary assetForURL:imageURL  
  
                   resultBlock:resultblock 
  
                  failureBlock:nil];
    
    NSData *data = UIImagePNGRepresentation(image);
    [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"data"];
    [_iconBtn setBackgroundImage:image forState:UIControlStateNormal];
    _iconBtn.layer.cornerRadius = 50;
    _iconBtn.layer.masksToBounds = YES;
    [picker dismissViewControllerAnimated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
