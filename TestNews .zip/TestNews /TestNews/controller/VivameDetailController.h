//
//  VivameDetailController.h
//  TestNews
//
//  Created by qianfeng on 15/10/14.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VivameModel.h"

@interface VivameDetailController : UIViewController


@property (nonatomic,strong)VivameModel *model;
@property (nonatomic,strong)NSString *url;
@property (nonatomic,strong)NSString *titleName;

@end
