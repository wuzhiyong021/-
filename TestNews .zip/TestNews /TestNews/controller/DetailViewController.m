//
//  DetailViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/15.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "DetailViewController.h"
#import "Masonry.h"
#import "DBManager.h"
#import "CommentDetailViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "UMSocial.h"
#import "SDWebImageDownloader.h"


#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;

@interface DetailViewController ()<UITextFieldDelegate>


@property (nonatomic,strong)UIButton *collectBtn;
@property (nonatomic,strong)UITextField *txtInput;
@property (nonatomic,strong)UIButton *commentBtn;

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor blackColor];
    [self createNav];
    [self createWebView];
    
    UIImageView *txtBg = [[UIImageView alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height-49, self.view.bounds.size.width, 49)];
    txtBg.userInteractionEnabled = YES;
    txtBg.image = [UIImage imageNamed:@"TabBackground@2x"];
    [self.view addSubview:txtBg];
    
    self.txtInput = [[UITextField alloc] initWithFrame:CGRectMake(10, 10, 260, 30)];
    self.txtInput.placeholder = @"爆发吧，奇思妙想小宇宙...";
    [self.txtInput setBackground:[UIImage imageNamed:@"CommentViewBackground1"]];
    [self.txtInput setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
    self.txtInput.delegate = self;
    [txtBg addSubview:self.txtInput];
    
    UIView *v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 1)];
    self.txtInput.leftView = v;
    self.txtInput.leftViewMode = UITextFieldViewModeAlways;
    
    self.commentBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.commentBtn setBackgroundImage:[UIImage imageNamed:@"CommentButton1@3x"] forState:UIControlStateNormal];
    [self.commentBtn setTitle:@"评论" forState:UIControlStateNormal];
    self.commentBtn.frame = CGRectMake(280, 10, 40 , 30);
    [self.commentBtn addTarget:self action:@selector(commentAction:) forControlEvents:UIControlEventTouchUpInside];
    [txtBg addSubview:self.commentBtn];
    
    //监听键盘的弹出事件
    //1.创建一个NSNotificationCenter对象
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    
    //2.监听键盘的弹出通知
    [center addObserver:self selector:@selector(keyBoardFrameWillChange:) name:UIKeyboardWillChangeFrameNotification object:nil];
}

- (void)commentAction: (id) sender{
    
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    NSMutableDictionary *dict=[NSMutableDictionary dictionary];
    [dict setObject:@"1" forKey:@"type"];
    [dict setObject:self.model.url forKey:@"id"];
    [dict setObject:@"123" forKey:@"nickname"];
    
    
    [dict setObject:self.txtInput.text forKey:@"content"];
    [dict setObject:self.model.title forKey:@"title"];
    [dict setObject:@"" forKey:@"magId"];
    [dict setObject:@"" forKey:@"pageNo"];
    [dict setObject:self.model.source forKey:@"sname"];
    [dict setObject:@"1" forKey:@"grade"];
    [dict setObject:@"-1" forKey:@"tagid"];
    [manager POST:@"http://interfacev5.vivame.cn/x1-interface-v5/json/comment.json?platform=android&installversion=5.6.6.3&channelno=BDSCA2320480100&mid=7c2f435b4eb9c9267addf21979bc88c4&uid=11024477&sid=beee10c2-52f7-4a6d-8b8e-6f5bdc1469ed" parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        NSLog(@"上传成功");
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    }];
    
    
    CommentDetailViewController *ctrl = [[CommentDetailViewController alloc] init];
    ctrl.tId = self.model.url;
    self.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:ctrl animated:YES];
}

- (void)keyBoardFrameWillChange:(NSNotification *)note{
    CGRect rectEnd = [note.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat keyboardY = rectEnd.origin.y;
    CGFloat tranformValue = keyboardY -self.view.frame.size.height;

    [UIView animateWithDuration:1 animations:^{
        self.view.transform =CGAffineTransformMakeTranslation(0, tranformValue);
    } completion:^(BOOL finished) {
        
    }];
    
    
}

- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    BOOL ret = [[DBManager sharedManager] isExists:self.model.url];
    if (ret) {
        [self.collectBtn setBackgroundImage:[UIImage imageNamed:@"commentcollectimage_select"] forState:UIControlStateNormal];
    }else{
        [self.collectBtn setBackgroundImage:[UIImage imageNamed:@"commentcollectimage_normal"] forState:UIControlStateNormal];
    }
}

- (void)createNav{
    WS(ws);
    UIView *bgView = [[UIView alloc] init];
    bgView.backgroundColor = [UIColor whiteColor];
    [ws.view addSubview:bgView];
    [bgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(ws.view);
        make.top.mas_equalTo(20);
        make.height.mas_equalTo(44);
        
    }];
    
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.backgroundColor = [UIColor blackColor];
    [bgView addSubview:imageView];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(42);
        make.left.equalTo(ws.view);
        make.right.equalTo(ws.view);
        make.height.mas_equalTo(1);
    }];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[UIImage imageNamed:@"TopBackBtnNor"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    [bgView addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(10);
        make.left.mas_equalTo(20);
        make.width.mas_equalTo(25);
        make.height.mas_equalTo(25);
    }];
    
    
    
    self.collectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.collectBtn setBackgroundImage:[UIImage imageNamed:@"commentcollectimage_normal"] forState:UIControlStateNormal];
    
    [self.collectBtn addTarget:self action:@selector(collectAction:) forControlEvents:UIControlEventTouchUpInside];
    [bgView addSubview:self.collectBtn];
    [self.collectBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(10);
        make.right.mas_equalTo(-20);
        make.width.mas_equalTo(25);
        make.height.mas_equalTo(25);
    }];
    
    
    UIButton *shareBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [shareBtn setBackgroundImage:[UIImage imageNamed:@"commentShareimage_normal@2x"] forState:UIControlStateNormal];
    [shareBtn addTarget:self action:@selector(shareAction:) forControlEvents:UIControlEventTouchUpInside];
    [bgView addSubview:shareBtn];
    [shareBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(10);
        make.right.mas_equalTo(-60);
        make.width.mas_equalTo(25);
        make.height.mas_equalTo(25);
    }];
}

- (void)shareAction:(id)btn{
    NSURL *url = [NSURL URLWithString:self.model.img];
    
    dispatch_queue_t queue =dispatch_queue_create("loadImage",NULL);
    dispatch_async(queue, ^{
        
        NSData *resultData = [NSData dataWithContentsOfURL:url];
        UIImage *img = [UIImage imageWithData:resultData];
        
        dispatch_sync(dispatch_get_main_queue(), ^{
            [UMSocialSnsService presentSnsIconSheetView:self
                                                 appKey:@"5661296fe0f55a2c10005a7b"
                                              shareText:[NSString stringWithFormat:@"#%@  %@  ",self.model.title,self.model.fileurl]
                                             shareImage:img
                                        shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToTencent,nil]
                                               delegate:self];
        });
        
    });
    
    
}


- (void)collectAction:(id)sender{
    BOOL ret = [[DBManager sharedManager] isExists:self.model.url];
    if (ret) {
        [[DBManager sharedManager] delegateModel:self.model.url];
        [self.collectBtn setBackgroundImage:[UIImage imageNamed:@"commentcollectimage_normal"] forState:UIControlStateNormal];
        
    }else{
        [[DBManager sharedManager] addModel:self.model];
        [self.collectBtn setBackgroundImage:[UIImage imageNamed:@"commentcollectimage_select"] forState:UIControlStateNormal];
    }
}

- (BOOL)prefersStatusBarHidden{
    return NO;
}

- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}




- (void)createWebView{
    WS(ws);
    UIWebView *wView = [[UIWebView alloc] init];
    [ws.view addSubview:wView];
    [wView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(64);
        make.left.equalTo(ws.view);
        make.right.equalTo(ws.view);
        make.bottom.equalTo(ws.view).offset(-49);
    }];
    NSMutableString *urlString = [NSMutableString string];
    if ([self.model.stypename isEqualToString:@"未知"]) {
        [urlString appendString:self.model.url];
    }else{
        [urlString appendString:self.model.fileurl];
    }
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    wView.scrollView.bounces = NO;
    [wView loadRequest:request];
}

- (void)backAction:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark-UITextFeild代理
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [self.commentBtn setTitle:@"发表" forState:UIControlStateNormal];
    [self.commentBtn removeTarget:self action:@selector(commentAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.commentBtn addTarget:self action:@selector(gotoDetail:) forControlEvents:UIControlEventTouchUpInside];
}

- (BOOL) textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    [self commentAction:self.commentBtn];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    [self.commentBtn setTitle:@"评论" forState:UIControlStateNormal];
    [self.commentBtn removeTarget:self action:@selector(gotoDetail:) forControlEvents:UIControlEventTouchUpInside];
    [self.commentBtn addTarget:self action:@selector(commentAction:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)gotoDetail:(UIButton *)btn{
    [self commentAction:self.commentBtn];
    [self.txtInput resignFirstResponder];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
