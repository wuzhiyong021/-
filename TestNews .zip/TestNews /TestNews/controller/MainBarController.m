//
//  MainBarController.m
//  TestNews
//
//  Created by qianfeng on 15/10/5.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "MainBarController.h"

@interface MainBarController ()

@end

@implementation MainBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self createView];
}

- (void)createView{
    
    //创建scrollView
    NSArray *controllView = @[@"HobbyViewController",@"DiscoveryViewController",@"VivameViewController"];
    //图片
    NSArray *imageArray = @[@"HobbyTab",@"DiscoveryTab",@"VivameTab"];
    //选择图片
    NSArray *selectImageArray= @[@"HobbySelTab@2x",@"DiscoverySelTab",@"VivameSelTab"];
    NSMutableArray *array = [NSMutableArray array];
    for ( int i =0; i<controllView.count; i++) {
        Class cls = NSClassFromString(controllView[i]);
        UIViewController *vCtrl = [[cls alloc] init];
        vCtrl.tabBarItem.image = [[UIImage imageNamed:imageArray[i]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        vCtrl.tabBarItem.selectedImage = [[UIImage imageNamed:selectImageArray[i]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        UINavigationController *navCtrl = [[UINavigationController alloc] initWithRootViewController:vCtrl];
        [array addObject:navCtrl];
    }
    self.viewControllers = array;
    //调整tabBar上的图标位置
    CGFloat offset = 10.0;
    for (UITabBarItem *item in self.tabBar.items) {
        item.imageInsets = UIEdgeInsetsMake(offset, 0, -offset, 0);
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
