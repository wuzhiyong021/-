//
//  HobbyViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/5.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "HobbyViewController.h"
#import "MyUtil.h"
#import "AFHTTPRequestOperationManager.h"
#import "NewsModel.h"
#import "BigImageViewCell.h"
#import "NewsCell.h"
#import "MJRefresh.h"
#import "DiscoveryImageCell.h"
#import "DetailViewController.h"
#import "HobbyHeaderView.h"
#import "SpiecalViewController.h"
#import "PhotoViewController.h"

#define Kurl (@"http://interfacev5.vivame.cn/x1-interface-v5/json/newdatalist.json?platform=android&installversion=5.6.6.3&channelno=BDSCA2320480100&mid=7c2f435b4eb9c9267addf21979bc88c4&uid=11024476&sid=b8bc94d0-0fef-4f64-890d-7c1de00412a0&type=-1&id=%ld&category=-1&ot=%ld&nt=0")

@interface HobbyViewController ()<UITableViewDataSource,UITableViewDelegate,MJRefreshBaseViewDelegate,HobbyHeaderViewDelegate>
{
    NSInteger _pageId;
    NSInteger _oldTimestamp;
    NSMutableArray *_dataArray;
    NSMutableArray *_newsDataArray;
    NSMutableArray *_adsArray;
    NSInteger _ot;
    
    UITableView *_tbView;
    BOOL _isLoading;
    NSMutableArray *_sectionNameArray;
    
    MJRefreshHeaderView *_headerView;
    MJRefreshFooterView *_footerView;
    AFHTTPRequestOperationManager *_manager;
    
}

@property (nonatomic,strong)UITableView *tbView;
@property (nonatomic,strong)HobbyHeaderView *hHeaderView;


@end

@implementation HobbyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _adsArray= [NSMutableArray array];
    _dataArray = [NSMutableArray array];
    _newsDataArray = [NSMutableArray array];
    _sectionNameArray = [NSMutableArray array];
    _pageId = -4;
    _ot = 0;
    _isLoading = NO;
    [self createScrollViewBtn];
    [self createTableView];
    [self downloadHeaderData];
    [self downloadData];
    
}


//创建tableView
- (void)createTableView{
    self.automaticallyAdjustsScrollViewInsets = NO;
    _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height-49-64) style:UITableViewStylePlain];
    _tbView.delegate = self;
    _tbView.dataSource = self;
    [self.view addSubview:_tbView];
    
    _headerView = [MJRefreshHeaderView header];
    _headerView.delegate = self;
    _headerView.scrollView = _tbView;
    

    _footerView = [MJRefreshFooterView footer];
    _footerView.delegate = self;
    _footerView.scrollView = _tbView;
    
    
   
}


//下载数据
- (void)downloadData{
    _isLoading = YES;
    
    _manager = [[AFHTTPRequestOperationManager alloc] init];
    _manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSString *urlString = [NSString stringWithFormat:Kurl,_pageId,_ot];
    
    __weak HobbyViewController *weakSelf=self;
    if (_pageId == -4) {
        [_manager GET:urlString parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
            //JSON解析
            id  result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            if ([result isKindOfClass:[NSDictionary class]]) {
                if (_ot == 0) {
                    self.tbView.contentOffset = CGPointZero;
                    [_dataArray removeAllObjects];
                }
                NSDictionary *dict = result;
                NSDictionary *dataDict = dict[@"data"];
                _oldTimestamp = [dataDict[@"oldTimestamp"] integerValue];
                //正文部分
                for (NSDictionary *itemsDict in dataDict[@"feedlist"]) {
                    NSMutableArray *array=[NSMutableArray array];
                    [_sectionNameArray addObject:itemsDict[@"name"]];
                    for (NSDictionary *aDict in itemsDict[@"items"]) {
                        NewsModel *model = [[NewsModel alloc] init];
                        [model setValuesForKeysWithDictionary:aDict];
                        //  NSLog(@"%@",model.title);
                        [array addObject:model];
                    }
                    [_dataArray addObject:array];
                }
            }
            _isLoading = NO;
            [weakSelf.tbView reloadData];
            [_headerView endRefreshing];
            [_footerView endRefreshing];

        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"%@",error);
            _isLoading = NO;
            [_headerView endRefreshing];
            [_footerView endRefreshing];
        }];
    }
     //除了第一页的下载
    [_manager GET:urlString parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //JSON解析
        id  result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if (_ot == 0) {
            self.tbView.contentOffset = CGPointZero;
            [_newsDataArray removeAllObjects];
        }
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dict = result;
            NSDictionary *dataDict = dict[@"data"];
            _oldTimestamp = [dataDict[@"oldTimestamp"] integerValue];
            //正文部分
            for (NSDictionary *itemsDict in dataDict[@"feedlist"]) {
                for (NSDictionary *aDict in itemsDict[@"items"]) {
                    NewsModel *model = [[NewsModel alloc] init];
                    [model setValuesForKeysWithDictionary:aDict];
                    if (model.title.length > 2 && ![model.stypename isEqualToString:@"杂志"]) {
                        [_newsDataArray addObject:model];
                    }
                    
                }
            }
        }
        _isLoading = NO;
        [_headerView endRefreshing];
        [_footerView endRefreshing];
        [weakSelf.tbView reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"%@",error);
        _isLoading = NO;
        [_headerView endRefreshing];
        [_footerView endRefreshing];
    }];
    
}

- (void)downloadHeaderData{
    _manager = [[AFHTTPRequestOperationManager alloc] init];
    _manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSString *urlString = [NSString stringWithFormat:Kurl,_pageId,_ot];
//    __weak HobbyViewController *weakSelf=self;
    [_manager GET:urlString parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [_adsArray removeAllObjects];
        //JSON解析
        id  result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dict = result;
            NSDictionary *dataDict = dict[@"data"];
            NSDictionary *bannerDict = dataDict[@"banner"];
            for (NSDictionary *itemDict in bannerDict[@"items"]) {
                NewsModel *model = [[NewsModel alloc] init];
                [model setValuesForKeysWithDictionary:itemDict];
                if ((![model.title isEqualToString:@""]) &&(![model.stypename isEqualToString:@"杂志"])) {
                    [_adsArray addObject:model];
                }
            }
        }
        if (_adsArray.count > 0 ) {
            self.hHeaderView = [[HobbyHeaderView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, 240)];
            self.hHeaderView.modelArray = _adsArray;
            self.hHeaderView.delegate = self;
            _tbView.tableHeaderView = self.hHeaderView;
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"%@",error);
    }];
}


//创建每一个分栏
- (void)createScrollViewBtn{
    NSArray *titleArray = @[@"首选",@"时事",@"娱乐",@"精读",@"军事",@"国际",@"体育",@"美女",@"健康"];
    for (int i=0; i<titleArray.count; i++) {
        UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
        [btn setTitle:titleArray[i] forState:UIControlStateNormal];
        CGRect frame= CGRectMake(4+(50+10)*i, 8, 50, 30) ;
        btn.frame=frame;
        btn.tag = 900+i;
        if (i == 0) {
            [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            self.mySelect = 900;
        }else{
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        }
        [btn addTarget:self action:@selector(reload:) forControlEvents:UIControlEventTouchUpInside];
        _scrollView.userInteractionEnabled = YES;
        [_scrollView addSubview:btn];
    }
    _scrollView.contentSize=CGSizeMake(60*titleArray.count, 30);
}

//实现分栏按钮的方法
- (void)reload:(UIButton *)btn{
    _footerView.hidden = NO;
    [_manager.operationQueue cancelAllOperations];
    //改变按钮颜色
    UIButton *btn2 = (UIButton *)[_scrollView viewWithTag:self.mySelect];
    [btn2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIButton *btn1 = (UIButton *)[_scrollView viewWithTag:btn.tag];
    [btn1 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    self.tbView.tableHeaderView = nil;
    [_newsDataArray removeAllObjects];
    [_adsArray removeAllObjects];
    self.mySelect = btn.tag;
    if (btn.tag - 900 == 0) {
        _pageId = -4;
    }else if(btn.tag - 900 == 1){
        _pageId = -1;
    }else if (btn.tag - 900 == 2){
        _pageId = 3;
    }else if (btn.tag - 900 == 3){
        _pageId = 31;
    }else if (btn.tag - 900 == 4){
        _pageId = 11;
    }else if (btn.tag - 900 == 5){
        _pageId = 1;
    }else if (btn.tag - 900 == 6){
        _pageId = 5;
    }else if (btn.tag - 900 == 7){
        _pageId = 13;
    }else if (btn.tag - 900 == 8){
        _pageId = 46;
    }
    
    [self downloadHeaderData];
    [self downloadData];

    [self.tbView reloadData];

}

-(void)dealloc{
    _headerView.scrollView = nil;
    _footerView.scrollView = nil;
    self.navigationController.navigationBar.hidden = NO;
//    [_manager.operationQueue cancelAllOperations];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark-UITableView代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (_pageId == -4) {
        if (_dataArray.count <= 0) {
            return 0;
        }else{
            return _dataArray.count-1;
        }
    }
    return 1;
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (_pageId == -4) {
        if (_dataArray.count > 2) {
            NSArray *array = _dataArray[section+1];
            return array.count;
        }else{
            return 1;
        }
    }else{
        return _newsDataArray.count;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (_pageId == -4) {
        if (_dataArray.count > 2 && indexPath.row == 0) {
            NSArray *array = _dataArray[indexPath.section+1];
            NewsModel *model = array[indexPath.row];
            if (model.img.length >10) {
                return 220;
            }
        }
    }else if (_pageId != -1) {
        if(_dataArray.count > 0){
            NewsModel *model =_newsDataArray[indexPath.row];
            if ((model.img.length >10) &&(model.imgHeight >= 560  || model.imgHeight == 0)) {
                return 340;
            }else{
                return 80;
            }
        }
    }
    return 80;
    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (_pageId == -4) {
        _footerView.hidden = YES;
        if (indexPath.section+1 < _dataArray.count) {
            NSArray *array = _dataArray[indexPath.section+1];
            NewsModel *model = array [indexPath.row];
            if (indexPath.row == 0 && model.img.length > 10) {
                static NSString *cellId = @"bigImageCellId";
                BigImageViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
                if (cell == nil) {
                    cell = [[[NSBundle mainBundle] loadNibNamed:@"BigImageViewCell" owner:nil options:nil] lastObject];
                }
//                NewsModel *model = array[indexPath.row];
                [cell configModel:model];
                
                NSString *str = _sectionNameArray[indexPath.section+1];
                [cell tipNameWith:str];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                return cell;
            }else{
                static NSString *cellId =@"newsCellId";
                NewsCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
                if (cell == nil) {
                    cell = [[[NSBundle mainBundle] loadNibNamed:@"NewsCell" owner:nil options:nil] lastObject];
                }
                if (indexPath.row < array.count) {
                    NewsModel *model1 = array[indexPath.row];
                    [cell configModel:model1];
                    return cell;
                }
                return cell;

            }
        }
    }
    else if (_pageId == -1){
        NewsModel *model = _newsDataArray[indexPath.row];
        static NSString *cellId =@"newsCellId";
        NewsCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"NewsCell" owner:nil options:nil] lastObject];
        }
        
        [cell configModel:model];
        return cell;
    }
    NewsModel *model = _newsDataArray[indexPath.row];
    if ((model.img.length >10) &&(model.imgHeight >= 560  || model.imgHeight == 0)) {
        static NSString *cellId = @"DiscoveryCellId";
        DiscoveryImageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle]loadNibNamed:@"DiscoveryImageCell" owner:nil options:nil] lastObject];
        }
        cell.model = model;
        return cell;
        
    }
    static NSString *cellId =@"newsCellId";
    NewsCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"NewsCell" owner:nil options:nil] lastObject];
    }
    
    [cell configModel:model];
    return cell;
        
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (_pageId == -4) {
        NSArray *array = _dataArray[indexPath.section+1];
        NewsModel *model = array[indexPath.row];
        if ([model.stypename isEqualToString:@"专题"]) {
            SpiecalViewController *sCtrl = [[SpiecalViewController alloc] init];
            sCtrl.model = model;
            self.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:sCtrl animated:YES];
            self.hidesBottomBarWhenPushed = NO;
        }else{
            DetailViewController *dCtrl = [[DetailViewController alloc] init];
            dCtrl.model = model;
            self.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:dCtrl animated:YES];
            self.hidesBottomBarWhenPushed = NO;
        }
        
    }else{
        NewsModel *model = _newsDataArray[indexPath.row];
        if ([model.stypename isEqualToString:@"专题"]) {
            SpiecalViewController *sCtrl = [[SpiecalViewController alloc] init];
            self.hidesBottomBarWhenPushed = YES;
            sCtrl.model = model;
            [self.navigationController pushViewController:sCtrl animated:YES];
            self.hidesBottomBarWhenPushed = NO;
        }else{
            DetailViewController *dCtrl = [[DetailViewController alloc] init];
            dCtrl.model = model;
            self.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:dCtrl animated:YES];
            self.hidesBottomBarWhenPushed = NO;
        }
    }
    
}

#pragma mark-MJRefresh代理
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView{
    if (_pageId == -4) {
        if (_isLoading) {
            return;
        }
        if (_headerView == refreshView) {
            _ot = 0;
            [self downloadHeaderData];
            [self downloadData];
        }else if (_footerView == refreshView){
            [_footerView endRefreshing];
        }
    }else{
        if (_isLoading) {
            return;
        }
        if (_headerView == refreshView) {
            _ot = 0;
            [self downloadHeaderData];
            [self downloadData];
        }else if(_footerView == refreshView){
            _ot = _oldTimestamp;
            [self downloadData];
        }
    }
    
}

#pragma mark-HobbyHeaderView代理
- (void)didSelectHearder:(NewsModel *)model{
    
    if ([model.stypename isEqualToString:@"专题"]) {
        SpiecalViewController *sCtrl = [[SpiecalViewController alloc] init];
        self.hidesBottomBarWhenPushed = YES;
        sCtrl.model = model;
        [self.navigationController pushViewController:sCtrl animated:YES];
        self.hidesBottomBarWhenPushed = NO;
    }else if ([model.fileurl isEqualToString:@""]){
        PhotoViewController *pCtrl = [[PhotoViewController alloc] init];
        pCtrl.urlString = model.url;
        self.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:pCtrl animated:YES];
        self.hidesBottomBarWhenPushed = NO;
    }else{
        DetailViewController *dCtrl = [[DetailViewController alloc] init];
        dCtrl.model = model;
        self.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:dCtrl animated:YES];
        self.hidesBottomBarWhenPushed = NO;
    }
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
