//
//  ActivityViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/16.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "ActivityViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "NewsModel.h"
#import "MJRefresh.h"
#import "DiscoveryImageCell.h"
#import "VivameDetailController.h"


#define kUrl (@"http://interfacev5.vivame.cn/x1-interface-v5/json/mypageant.json?platform=android&installversion=5.6.6.3&channelno=BDSCA2320480100&mid=7c2f435b4eb9c9267addf21979bc88c4&uid=11092073&sid=8c9c5035-dcba-46cd-8270-4e50da17e1f2&ichannelno=")

@interface ActivityViewController ()<MJRefreshBaseViewDelegate,UITableViewDataSource,UITableViewDelegate>

{
    BOOL _isLoading;
    MJRefreshHeaderView *_hearderView;
    
}

@property (nonatomic,strong)UITableView *tbView;
@property (nonatomic,strong)NSMutableArray *dataArray;

@end

@implementation ActivityViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _isLoading = NO;
    self.dataArray = [NSMutableArray array];
    [self createTabView];
    [self downloaderData];
    [self addNavTitle:@"精彩活动"];
    
}


- (void)downloaderData{
    _isLoading = YES;
    
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    __weak ActivityViewController *weakSelf = self;
    
    [manager GET:kUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        id  result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        [_dataArray removeAllObjects];
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dict = result;
            NSDictionary *dataDict = dict[@"data"];
            for (NSDictionary *itemsDict in dataDict[@"feedlist"]) {
                for (NSDictionary *aDict in itemsDict[@"items"]) {
                    NewsModel *model = [[NewsModel alloc] init];
                    [model setValuesForKeysWithDictionary:aDict];
                    if (model.title.length >2 && ![model.stypename isEqualToString:@"杂志"]) {
                        [weakSelf.dataArray addObject:model];
                    }
                }
            }
            _isLoading = NO;
            [_hearderView endRefreshing];
            [weakSelf.tbView reloadData];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        _isLoading = NO;
        [_hearderView endRefreshing];
//        NSLog(@"%@",error);
    }];
    
}


- (void)createTabView{
    self.tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height -49)];
    self.tbView.dataSource = self;
    self.tbView.delegate = self;
    [self.view addSubview:self.tbView];
    
    _hearderView  = [MJRefreshHeaderView header];
    _hearderView.delegate = self;
    _hearderView.scrollView = self.tbView;
    
    
}


#pragma mark-UITableView代理
-  (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 340;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"DiscoveryCellId";
    DiscoveryImageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"DiscoveryImageCell" owner:nil options:nil] lastObject];
    }
    NewsModel *model = self.dataArray[indexPath.row];
    cell.model = model;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    VivameDetailController *ctrl = [[VivameDetailController alloc] init];
    NewsModel *model = self.dataArray[indexPath.row];
    ctrl.url = model.url;
    ctrl.titleName = model.title;
    [self.navigationController pushViewController:ctrl animated:YES];
}

#pragma mark-MJRefresh代理
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView{
    if (_isLoading) {
        return;
    }
    if (_hearderView == refreshView) {
        [self downloaderData];
    }
}


- (void)dealloc{
    _hearderView.scrollView = nil;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
