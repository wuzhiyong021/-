//
//  SpiecalViewController.h
//  TestNews
//
//  Created by qianfeng on 15/10/20.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "HeaderBaseViewController.h"
#import "NewsModel.h"

@interface SpiecalViewController : HeaderBaseViewController

@property (nonatomic,strong)NewsModel *model;

@end
