//
//  PhotoViewController.h
//  TestNews
//
//  Created by qianfeng on 15/10/14.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VivameModel.h"
#import "AFHTTPRequestOperationManager.h"

@interface PhotoViewController : UIViewController

@property (nonatomic,strong)VivameModel *model;
@property (nonatomic,strong)NSString *urlString;

@end
