//
//  SearchViewController.h
//  TestNews
//
//  Created by qianfeng on 15/10/18.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchViewController : UIViewController


@property (nonatomic,strong)UITextField *searchField;
@property (nonatomic,strong)UIButton *searchBtn;


- (void)downloadData;
- (void)searchAction:(id)sender;

@end
