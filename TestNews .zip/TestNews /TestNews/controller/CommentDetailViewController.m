//
//  CommentDetailViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/24.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "CommentDetailViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "CommentModel.h"
#import "CommentDetailViewCell.h"

#define kUrl (@"http://interfacev5.vivame.cn/x1-interface-v5/json/commentlist.json?platform=android&installversion=5.6.6.3&channelno=BDSCA2320480100&mid=7c2f435b4eb9c9267addf21979bc88c4&uid=11024476&sid=beee10c2-52f7-4a6d-8b8e-6f5bdc1469ed&type=1&id=%@&pageindex=0&pagesize=90")

@interface CommentDetailViewController ()<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>

@property (nonatomic,strong)NSMutableArray *dataArray;
@property (nonatomic,strong)UITableView *tbView;
@property (nonatomic,assign)CGFloat height;

@end

@implementation CommentDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dataArray = [NSMutableArray array];
    self.view.backgroundColor = [UIColor grayColor];
    [self addNavTitle:@"评论"];
    [self downloadData];
    [self createTableView];
}

- (void)createTableView{
    self.tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height- 49)];
    self.tbView.backgroundColor = [UIColor grayColor];
    self.tbView.delegate = self;
    self.tbView.dataSource = self;
    [self.view addSubview:self.tbView];
}

- (void)downloadData{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSString *url = [NSString stringWithFormat:kUrl,self.tId];
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        id data = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if ([data isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dict = data;
            for (NSDictionary *dataDict in dict[@"data"]) {
                CommentModel *model = [[CommentModel alloc] init];
                model.nickName = dataDict[@"nickname"];
                model.content = dataDict[@"content"];
                [self.dataArray addObject:model];
            }
        }
        if (self.dataArray.count == 0) {
            UIAlertView *a = [[UIAlertView alloc] initWithTitle:@"提示" message:@"当前没有评论" delegate:self cancelButtonTitle:nil otherButtonTitles:@"抢沙发去", nil];
            [a show];
        }else{
            [self.tbView reloadData];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}

#pragma mark - UIAlertView代理
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}


#pragma mark - UITableView代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"commentCellId";
    CommentDetailViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    cell.backgroundColor = [UIColor grayColor];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"CommentDetailViewCell" owner:nil options:nil] lastObject];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    CommentModel *model = self.dataArray[indexPath.row];
    self.height = [cell heightWithModel:model];
    [cell configModel:model];
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
