//
//  DetailViewController.h
//  TestNews
//
//  Created by qianfeng on 15/10/15.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsModel.h"

@interface DetailViewController : UIViewController

@property (nonatomic,strong)NewsModel *model;

@end
