//
//  TaskViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/16.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "TaskViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "TaskModel.h"
#import "TaskCell.h"


#define kUrl (@"http://interfacev5.vivame.cn/x1-interface-v5/json/task.json?platform=android&installversion=5.6.6.3&channelno=BDSCA2320480100&uid=11092073&mid=7c2f435b4eb9c9267addf21979bc88c4")

@interface TaskViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong)UITableView *tbView;
@property (nonatomic,strong)NSMutableArray *dailyArray;
@property (nonatomic,strong)NSMutableArray *dataArray;


@end

@implementation TaskViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dailyArray = [NSMutableArray array];
    self.dataArray = [NSMutableArray array];
    [self addNavTitle:@"每日任务"];
    [self createTableView];
    [self downloadData];
    
}

- (void)downloadData{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    __weak TaskViewController *weakSelf = self;
    [manager GET:kUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        id result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dict = result;
            NSDictionary *dataDict = dict[@"data"];
            for (NSDictionary *dailyTasksDict in dataDict[@"dailyTasks"]) {
                TaskModel *model = [[TaskModel alloc] init];
                model.title = dailyTasksDict[@"title"];
                model.awardCount = [dailyTasksDict[@"awardCount"] integerValue];
                [weakSelf.dailyArray addObject:model];
            }
            for (NSDictionary *bountyTasksDict in dataDict[@"bountyTasks"]) {
                TaskModel *model = [[TaskModel alloc] init];
                model.title = bountyTasksDict[@"title"];
                model.awardCount = [bountyTasksDict[@"awardCount"] integerValue];
                [weakSelf.dataArray addObject:model];
            }
        }
        [weakSelf.tbView reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"%@",error);
    }];
    
}

- (void)createTableView{
    self.tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height-64) style:UITableViewStylePlain];
    self.tbView.dataSource = self;
    self.tbView.delegate = self;
    [self.view addSubview:self.tbView];
    self.tabBarController.view.backgroundColor = [UIColor grayColor];
}

#pragma mark-UITableView代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return self.dailyArray.count;
    }else{
        return self.dataArray.count;
    }
    
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    if (indexPath.row == 0) {
//        return 40;
//    }
//    return 60;
//}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"taskCellId";
    TaskCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"TaskCell" owner:nil options:nil] lastObject];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (indexPath.section == 0) {
        TaskModel *model = self.dailyArray[indexPath.row];
        cell.model = model;
        return cell;
    }
    TaskModel *model = self.dataArray[indexPath.row];
    cell.model = model;
    return cell;
    
    
    
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return @"日常任务";
    }else{
        return @"赏金任务";
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
