//
//  LoadViewController.h
//  TestNews
//
//  Created by  on 11/11/2015.
//  Copyright © 2015 wuzhiyong. All rights reserved.
//

#import "HeaderBaseViewController.h"

@interface LoadViewController : HeaderBaseViewController


@end
