//
//  SpiecalViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/20.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "SpiecalViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "SpecialHeaderView.h"
#import "NewsCell.h"
#import "VivameDetailController.h"

#define kUrl (@"http://interfacev5.vivame.cn/x1-interface-v5/json/special.json?platform=android&installversion=5.6.6.3&channelno=BDSCA2320480100&mid=7c2f435b4eb9c9267addf21979bc88c4&uid=11092073&sid=44d1a1d6-0500-486e-a0b1-28974573732e&id=%@&type=0")


@interface SpiecalViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong)UITableView *tbView;
@property (nonatomic,strong)NSMutableArray *dataArray;
@property (nonatomic,strong)UILabel *descLabel;
@property (nonatomic,strong)UIImageView *imageView;

@end



@implementation SpiecalViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dataArray = [NSMutableArray array];
    self.view.backgroundColor = [UIColor redColor];
    [self cretaTableView];
    [self downloadData];
}

- (void)cretaTableView{
    self.tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height-64) style:UITableViewStylePlain];
    self.tbView.dataSource = self;
    self.tbView.delegate = self;
    [self.view addSubview:self.tbView];
}


- (void)downloadData{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSString *url = [NSString stringWithFormat:kUrl,self.model.url] ;

    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        id result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dict = result;
            NSDictionary *dataDict = dict[@"data"];
            NSMutableArray *array = [NSMutableArray array];
            NSMutableArray *array1 = [NSMutableArray array];
            NSMutableArray *array2 = [NSMutableArray array];
            for (NSDictionary *feedListDict in dataDict[@"feedlist"]) {
                if ([feedListDict[@"name"] isEqualToString:@""]) {
                    for (NSDictionary *itemDict in feedListDict[@"items"]) {
                        NewsModel *model = [[NewsModel alloc] init];
                        [model setValuesForKeysWithDictionary:itemDict];
                        [array addObject:model];
                    }
                }else if ([feedListDict[@"name"] isEqualToString:@"最新报道"]) {
                    for (NSDictionary *itemDict in feedListDict[@"items"]) {
                        NewsModel *model = [[NewsModel alloc] init];
                        [model setValuesForKeysWithDictionary:itemDict];
                        [array1 addObject:model];
                    }
                }else{
                    for (NSDictionary *itemDict in feedListDict[@"items"]) {
                        NewsModel *model = [[NewsModel alloc] init];
                        [model setValuesForKeysWithDictionary:itemDict];
                        [array2 addObject:model];
                    }
                }
            }
            if (array.count > 2) {
                NewsModel *model = array[0];
                NewsModel *model1 = array[1];
                model.desc = model1.desc;
                SpecialHeaderView *hView = [[SpecialHeaderView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, 280)];
                hView.model = model;
                self.tbView.tableHeaderView = hView;
            }else{
                self.tbView.tableFooterView = nil;
            }
            
          
            
            [_dataArray addObject:array1];
            [_dataArray addObject:array2];
            [self.tbView reloadData];
            
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"%@",error);
    }];
}

#pragma mark-UITableView代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSArray *array = self.dataArray[section];
    return array.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 80;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"newsCellId";
    NewsCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"NewsCell" owner:nil options:nil] lastObject];
    }
    NSArray *array = self.dataArray[indexPath.section];
    NewsModel *model = array[indexPath.row];
    [cell configModel:model];
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return @"最新报道";
    }
    return @"分析解读";
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    VivameDetailController *dctrl = [[VivameDetailController alloc] init];
    NSArray *array = self.dataArray[indexPath.section];
    NewsModel *model = array[indexPath.row];
    dctrl.url = model.url;
    dctrl.titleName = model.title;
    self.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:dctrl animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
