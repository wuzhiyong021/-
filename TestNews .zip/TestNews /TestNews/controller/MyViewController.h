//
//  MyViewController.h
//  TestNews
//
//  Created by qianfeng on 15/10/16.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "HeaderBaseViewController.h"

@interface MyViewController : HeaderBaseViewController

@end
