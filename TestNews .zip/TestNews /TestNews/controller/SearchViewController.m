//
//  SearchViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/18.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "SearchViewController.h"
#import "Masonry.h"
#import "AFHTTPRequestOperationManager.h"
#import "ShopModel.h"
#import "SearchCollectionViewCell.h"
#import "SearchResultViewController.h"



#define kCell (@"searchCollectionCellId")
#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;

@interface SearchViewController ()<UITextFieldDelegate,UICollectionViewDataSource,UICollectionViewDelegate,SearchCollectionViewCellDelegate>

@property (nonatomic,strong)UIView *navView;

@property (nonatomic,strong)UICollectionView *collView;
@property (nonatomic,strong)NSMutableArray *dataArray;

@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.dataArray = [NSMutableArray array];
    [self createNavView];
    [self downloadData];
    

}

- (void)downloadData{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    __weak SearchViewController *weakSelf = self;
    [manager GET:@"http://interfacev5.vivame.cn/x1-interface-v5/json/searchtag.json?platform=android&installversion=5.6.6.3&channelno=BDSCA2320480100&mid=7c2f435b4eb9c9267addf21979bc88c4&uid=11092073&sid=276d1c94-7408-40bf-94a7-b6aee47b3de2" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        id data = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if ([data isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dict = data;
            for (NSDictionary *dataDict in dict[@"data"]) {
                ShopModel *model = [[ShopModel alloc] init];
                model.name = dataDict[@"name"];
                model.type = [dataDict[@"isMark"] integerValue];
//                NSLog(@"%@,%ld",model.name,model.type);
                [weakSelf.dataArray addObject:model];
            }
        }
        [weakSelf createCollectionView];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
    }];
}

- (void)createCollectionView{
    WS(ws);
    self.automaticallyAdjustsScrollViewInsets = NO;
    UILabel *label = [[UILabel alloc] init];
    label.text = @"大家都在搜";
    label.font = [UIFont systemFontOfSize:18];
    label.textColor = [UIColor grayColor];
    [ws.view addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(68);
        make.width.mas_equalTo(100);
        make.height.mas_equalTo(24);
        make.left.mas_equalTo(10);
    }];
    
    UIView *grayView = [[UIView alloc] init];
    grayView.backgroundColor = [UIColor grayColor];
    [ws.view addSubview:grayView];
    [grayView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(93);
        make.width.equalTo(ws.view);
        make.height.mas_equalTo(1);
        make.left.mas_equalTo(0);
    }];
    
    
    //创建collectionView
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.sectionInset = UIEdgeInsetsMake(5, 0, 5, 0);
    layout.itemSize =CGSizeMake(self.view.bounds.size.width/3.0f, 40);
    layout.minimumInteritemSpacing = 0;
    layout.minimumLineSpacing = 0;
    
    self.collView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 94, self.view.bounds.size.width, self.view.bounds.size.height-94) collectionViewLayout:layout];
    self.collView.backgroundColor = [UIColor whiteColor];
    self.collView.delegate = self;
    self.collView.dataSource = self;
    [self.collView registerNib:[UINib nibWithNibName:@"SearchCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:kCell];
    [self.view addSubview:self.collView];
}

//自定制导航
- (void)createNavView{
    WS(ws);
    self.navView = [[UIView alloc] init];
    self.navView.backgroundColor = [UIColor blackColor];
    [ws.view addSubview:ws.navView];
    [ws.navView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(0);
        make.width.equalTo(ws.view);
        make.height.mas_equalTo(60);
    }];
    
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setBackgroundImage:[UIImage imageNamed:@"back@2x"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    [ws.navView addSubview:leftBtn];
    [leftBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(ws.navView.mas_left).with.offset(10);
        make.width.mas_equalTo(20);
        make.top.mas_equalTo(25);
        make.height.mas_equalTo(30);
    }];
    
  
    ws.searchField = [[UITextField alloc] init];
    ws.searchField.delegate = self;
    ws.searchField.backgroundColor = [UIColor whiteColor];
    ws.searchField.clearButtonMode = UITextFieldViewModeAlways;
    ws.searchField.borderStyle = UITextBorderStyleRoundedRect;
    ws.searchField.returnKeyType = UIReturnKeyGoogle;
    [ws.navView addSubview:ws.searchField];
    [ws.searchField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(35);
        make.top.mas_equalTo(25);
        make.right.equalTo(ws.navView).with.offset(-55);
        make.height.mas_equalTo(30);
    }];
    ws.searchField.placeholder =@"请输入关键字";
    //改变字体颜色
    [ws.searchField setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
    //改变字体的大小
    [ws.searchField setValue:[UIFont systemFontOfSize:15] forKeyPath:@"_placeholderLabel.font"];
    
    ws.searchBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [ws.searchBtn setTitle:@"搜索" forState:UIControlStateNormal];
    [ws.searchBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    ws.searchBtn.titleLabel.font = [UIFont systemFontOfSize:20];
    [ws.navView addSubview:ws.searchBtn];
    [ws.searchBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(ws.navView).offset(-5);
        make.top.mas_equalTo(25);
        make.width.mas_equalTo(50);
        make.height.mas_equalTo(30);
    }];
}


//状态栏的显示
- (BOOL)prefersStatusBarHidden{
    return NO;
}

- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}


- (void)backAction:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

//点击搜索按钮的事件
- (void)searchAction:(id)sender{
    [self.searchField resignFirstResponder];
    [self.searchBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    SearchResultViewController *ctrl = [[SearchResultViewController alloc] init];
    ctrl.textString = self.searchField.text;
    self.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:ctrl animated:YES];
}


#pragma mark-UITextFiled代理
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    [self searchAction:self.searchBtn];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [self.searchBtn addTarget:self action:@selector(searchAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.searchBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
}

#pragma mark-UICollectionView代理
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataArray.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{

    SearchCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kCell forIndexPath:indexPath];
    cell.layer.borderColor = [UIColor grayColor].CGColor;
    cell.layer.borderWidth = 0.5;
    ShopModel *model = self.dataArray[indexPath.item];
    //    cell.backgroundColor = [UIColor whiteColor];
    [cell configModel:model];
    cell.delegate = self;
    return cell;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark- SearchCollectionViewCell代理
- (void)textFeildName:(NSString *)name{
    [self.searchField resignFirstResponder];
    self.searchField.text = name;
    [self textFieldDidBeginEditing:self.searchField];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
