//
//  VivameViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/8.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "VivameViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "VivameModel.h"
#import "VivameCell.h"
#import "MJRefresh.h"
#import "MyUtil.h"
#import "VivameDetailController.h"
#import "PhotoViewController.h"

#define KUrl (@"http://interfacev5.vivame.cn/x1-interface-v5/json/community/square.json?platform=android&installversion=5.6.6.3&channelno=BDSCA2320480100&mid=7c2f435b4eb9c9267addf21979bc88c4&uid=11092073&sid=8c9c5035-dcba-46cd-8270-4e50da17e1f2&ot=%ld&nt=0&manual=1")

@interface VivameViewController ()<UITableViewDataSource,UITableViewDelegate,MJRefreshBaseViewDelegate,VivameDelegate>
{
    UITableView *_tbView;
    NSInteger _ot;
    NSInteger _oldTime;
    NSMutableArray *_dataArray;
    
    MJRefreshHeaderView *_headerView;
    MJRefreshFooterView *_footerView;
    BOOL _isLoading;
    CGFloat _height;
}
@end

@implementation VivameViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    self.navigationController.navigationBar.barStyle =UIBarStyleBlack;
    _isLoading = NO;
    _ot = 0;
    _dataArray = [NSMutableArray array];
    [self addNavTitle:@"V社区"];
    [self createTableView];
    [self downloadData];
    
}

//创建导航标题
- (void)addNavTitle:(NSString *)title{
    UILabel *label = [MyUtil createLabelFrame:CGRectMake(80, 0, 215, 44) title:title];
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont systemFontOfSize:28];
    label.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = label;
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)dealloc{
    _headerView = nil;
    _footerView = nil;
}


//下载数据
- (void)downloadData{
    _isLoading = YES;
    
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSString *urlString = [NSString stringWithFormat:KUrl,_ot];
    [manager GET:urlString parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (_ot == 0) {
            [_dataArray removeAllObjects];
        }

        id result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dict = result;
            NSDictionary *dataDict =dict[@"data"];
            NSDictionary *communityMessageListVoDict  = dataDict[@"communityMessageListVo"];
            _oldTime = [communityMessageListVoDict[@"oldTimeStamp"] integerValue];
            for (NSDictionary *communityMessageListDict in communityMessageListVoDict[@"communityMessageList"]) {
                VivameModel *model = [[VivameModel alloc] init];
                NSDictionary *commentObjectDict  = communityMessageListDict[@"commentObject"];
                model.objectType = [commentObjectDict[@"objectType"] integerValue];
                model.content = commentObjectDict[@"content"];
                model.objectId = commentObjectDict[@"objectId"];
                model.objectTitle = commentObjectDict[@"objectTitle"];
                model.objectImg = commentObjectDict[@"objectImg"];
                NSDictionary *communityUserDict = communityMessageListDict[@"communityUser"];
                model.nickName = communityUserDict[@"nickName"];
                model.headIcon = communityUserDict[@"headIcon"];
                model.title = communityUserDict[@"title"];
                
                NSDictionary *likeInfoDict = communityMessageListDict[@"likeInfo"];
                model.likecount = [likeInfoDict[@"likeCount"] integerValue];
                [_dataArray addObject:model];
            }
        }
        _isLoading=NO;
        [_headerView endRefreshing];
        [_footerView endRefreshing];
        [_tbView reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
//        _isLoading=NO;
        [_headerView endRefreshing];
        [_footerView endRefreshing];
    }];
    
}

//创建tabLeView视图
- (void)createTableView{
    self.automaticallyAdjustsScrollViewInsets = NO;
    _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height-64-49)];
    _tbView.delegate = self;
    _tbView.dataSource = self;
    [self.view addSubview:_tbView];
    
    _headerView = [MJRefreshHeaderView header];
    _headerView.delegate = self;
    _headerView.scrollView =_tbView;
                   
    _footerView = [MJRefreshFooterView footer];
    _footerView.delegate = self;
    _footerView.scrollView = _tbView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark-UITableView 代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return _height;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"VivameCellId";
    VivameCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
   
    cell.selectionStyle = UITableViewCellAccessoryNone;
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"VivameCell" owner:nil options:nil] lastObject];
    }
    VivameModel *model = _dataArray[indexPath.row];
    
    _height = [cell heightWithModel:model];
    [cell configModel:model];
    cell.delegate = self;
    return cell;
}




#pragma mark-MJRefreshView代理
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView{
    if (_isLoading) {
        return;
    }
    if (refreshView == _headerView) {
        _ot = 0;
        [self downloadData];
    }else{
        _ot = _oldTime;
        [self downloadData];
    }
}


#pragma mark-VivameCell代理
- (void)GotoDetail:(VivameModel *)model{
    if (model.objectType != 3) {
        VivameDetailController *ctrl = [[VivameDetailController alloc] init];
        ctrl.url = model.objectId;
        ctrl.model = model;
        self.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:ctrl animated:YES];
        self.hidesBottomBarWhenPushed = NO;
    }else{
        PhotoViewController *pCtrl = [[PhotoViewController alloc] init];
        pCtrl.model = model;
        self.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:pCtrl animated:YES];
        self.hidesBottomBarWhenPushed = NO;
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
