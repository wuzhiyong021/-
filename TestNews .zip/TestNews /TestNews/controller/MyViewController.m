//
//  MyViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/16.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "MyViewController.h"
#import "DBManager.h"
#import "NewsCell.h"
#import "DetailViewController.h"
#import "HobbyViewController.h"

@interface MyViewController ()<UITableViewDataSource,UITableViewDelegate>


@property (nonatomic,strong)NSMutableArray *dataArray;
@property (nonatomic,strong)UITableView *tbView;

@end

@implementation MyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self addNavTitle:@"我的收藏"];
    [self createTableView];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSArray *array = [[DBManager sharedManager] searchAllData];
    if (array.count == 0) {
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"您还没有收藏任何的东西" delegate:self cancelButtonTitle:@"去阅读" otherButtonTitles:@"确定",nil];
        [alertView show];
    }else{
        __weak MyViewController *weakSelf =self;
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            weakSelf.dataArray = [NSMutableArray arrayWithArray:array];
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.tbView reloadData];
            });
        });
    }
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        HobbyViewController *ctrl  = [[HobbyViewController alloc] init];
        [self.navigationController pushViewController:ctrl animated:YES];
    }else{
        return;
    }
}


- (void)createTableView{
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height-64) style:UITableViewStylePlain];
    self.tbView.dataSource = self;
    self.tbView.delegate = self;
    [self.view addSubview:self.tbView];
}


#pragma mark-UITableView代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 80;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"newsCellId";
    NewsCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"NewsCell" owner:nil options:nil] lastObject];
    }
    NewsModel *model = self.dataArray[indexPath.row];
    [cell configModel:model];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    DetailViewController *dCtrl = [[DetailViewController alloc] init];
    NewsModel *model = self.dataArray[indexPath.row];
    dCtrl.model = model;
    [self.navigationController pushViewController:dCtrl animated:YES];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    NewsModel *model = self.dataArray[indexPath.row];
    [[DBManager sharedManager] delegateModel:model.url];
    [self.dataArray removeObjectAtIndex:indexPath.row];
    [self.tbView reloadData];
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    return @"删除";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
