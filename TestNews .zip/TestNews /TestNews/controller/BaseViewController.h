//
//  BaseViewController.h
//  TestNews
//
//  Created by qianfeng on 15/10/5.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyUtil.h"
#import "Masonry.h"

@interface BaseViewController : UIViewController
{
    UIScrollView *_scrollView;
}




@end
