//
//  HeaderBaseViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/16.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "HeaderBaseViewController.h"
#import "Masonry.h"


#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;
@interface HeaderBaseViewController ()

@property (nonatomic,strong)UIView *navView;

@end

@implementation HeaderBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self createNavView];
    
}


//自定制导航
- (void)createNavView{
    WS(ws);
    self.navView = [[UIView alloc] init];
    self.navView.backgroundColor = [UIColor blackColor];
    [ws.view addSubview:ws.navView];
    [ws.navView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(0);
        make.width.equalTo(ws.view);
        make.height.mas_equalTo(64);
    }];
    
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setBackgroundImage:[UIImage imageNamed:@"back@2x"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    [ws.navView addSubview:leftBtn];
    [leftBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(ws.navView.mas_left).with.offset(10);
        make.width.mas_equalTo(20);
        make.top.mas_equalTo(30);
        make.height.mas_equalTo(30);
    }];
    
}

- (void)addNavTitle:(NSString *)titleName{
    UILabel *label = [[UILabel alloc] init];
    label.text = titleName;
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont systemFontOfSize:20];
    [self.navView addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(30);
        make.top.mas_equalTo(30);
        make.width.mas_equalTo(100);
        make.height.mas_equalTo(30);
    }];
}


//状态栏的显示
- (BOOL)prefersStatusBarHidden{
    return NO;
}

- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}


- (void)backAction:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
