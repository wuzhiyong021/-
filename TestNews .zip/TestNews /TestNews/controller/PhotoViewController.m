//
//  PhotoViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/14.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "PhotoViewController.h"
#import "PhotoModel.h"
#import "UIImageView+WebCache.h"



#define kUrl (@"http://interfacev5.vivame.cn/x1-interface-v5/json/gallery.json?platform=android&installversion=5.6.6.3&channelno=BDSCA2320480100&mid=7c2f435b4eb9c9267addf21979bc88c4&uid=11092073&sid=8eab5298-6a59-4df9-af8d-2c96f52e0d75&type=3&id=%@")

@interface PhotoViewController ()<UIScrollViewDelegate>

@property (nonatomic,strong)NSMutableArray *dataArray;
@property (nonatomic,strong)UIScrollView *scrollView;
@property (nonatomic,strong)UILabel *label;

@end

@implementation PhotoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor blackColor];
    self.navigationController.navigationBar.hidden = YES;
    self.dataArray = [NSMutableArray array];
    [self downloadData];
    [self createBackBtn];

}



- (void)downloadData{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSMutableString *url = [NSMutableString string];
    if (self.model.objectId) {
        [url appendFormat:kUrl,self.model.objectId];
    }else{
        [url appendFormat:kUrl,self.urlString];
    }
    
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        id result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dict =result;
            NSDictionary *dataDict = dict[@"data"];
            for (NSDictionary *itemsDict in dataDict[@"items"]) {
                PhotoModel *model = [[PhotoModel alloc] init];
                [model setValuesForKeysWithDictionary:itemsDict];
                [self.dataArray addObject:model];
            }
        }
        [self createScrollView];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"%@",error);
    }];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.hidden = NO;
}

- (void)createScrollView{
    self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0,100 , self.view.bounds.size.width, 360)];
    [self.view addSubview:self.scrollView];
        for (int i=0; i<self.dataArray.count; i++) {
            PhotoModel *model = self.dataArray[i];
            //图片
            UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(self.scrollView.bounds.size.width*i, 0, self.scrollView.bounds.size.width, 360)];
          
            [imageView sd_setImageWithURL:[NSURL URLWithString:model.img]];
            [self.scrollView addSubview:imageView];
            
        }
    self.scrollView.delegate = self;
    self.scrollView.contentSize = CGSizeMake(self.scrollView.bounds.size.width*self.dataArray.count, 0);
    self.scrollView.bounces = NO;
    self.scrollView.pagingEnabled = YES;

    self.label = [[UILabel alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height*0.7, self.view.bounds.size.width, 150)];
    self.label.textColor = [UIColor whiteColor];
    self.label.font = [UIFont systemFontOfSize:15];
    self.label.textAlignment = NSTextAlignmentJustified;
    self.label.numberOfLines = 0;
    PhotoModel *model = self.dataArray[0];
    self.label.text = model.desc;
    [self.view addSubview:self.label];
    
    
}

- (void)createBackBtn{
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height*0.926, self.view.bounds.size.width, 49)];
    backView.backgroundColor = [UIColor blackColor];
    [self.view addSubview:backView];
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(20, 10, 30, 30);
    [btn setBackgroundImage:[UIImage imageNamed:@"backImage_sel"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:btn];
}

- (void)backAction:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    NSInteger index = scrollView.contentOffset.x/scrollView.bounds.size.width;
    PhotoModel *model = self.dataArray[index];
    self.label.text =model.desc;
    
}

- (void)back{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
