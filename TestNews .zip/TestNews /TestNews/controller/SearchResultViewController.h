//
//  SearchResultViewController.h
//  TestNews
//
//  Created by qianfeng on 15/10/19.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "SearchViewController.h"

@interface SearchResultViewController : SearchViewController


@property (nonatomic,strong)NSString *textString;

@end
