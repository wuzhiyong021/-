//
//  HeaderBaseViewController.h
//  TestNews
//
//  Created by qianfeng on 15/10/16.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeaderBaseViewController : UIViewController


- (void)addNavTitle:(NSString *)titleName;

@end
