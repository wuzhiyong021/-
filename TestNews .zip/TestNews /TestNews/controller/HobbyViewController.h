//
//  HobbyViewController.h
//  TestNews
//
//  Created by qianfeng on 15/10/5.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "BaseViewController.h"


@interface HobbyViewController : BaseViewController

@property (nonatomic,assign)NSInteger mySelect;

@end
