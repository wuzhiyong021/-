//
//  SearchResultViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/19.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "SearchResultViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "NewsModel.h"
#import "DetailViewController.h"
#import "SearchResultViewCell.h"


#define kSearchUrl (@"http://interfacev5.vivame.cn/x1-interface-v5/json/search.json?platform=android&installversion=5.6.6.3&channelno=BDSCA2320480100&mid=7c2f435b4eb9c9267addf21979bc88c4&uid=11092073&sid=d89a63a5-b934-476e-b1df-504fe7ca2e7d")

@interface SearchResultViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong)NSMutableArray *dataArray;
@property (nonatomic,strong)UITableView *tbView;

@end

@implementation SearchResultViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.searchField.text = self.textString;
    self.dataArray = [NSMutableArray array];
    [self createTableView];

}


- (void)createTableView{
    self.tbView = [[UITableView alloc] initWithFrame:CGRectMake(5, 64, self.view.bounds.size.width-10, self.view.bounds.size.height-64) style:UITableViewStylePlain];
    self.tbView.dataSource = self;
    self.tbView.delegate = self;
    self.tbView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:self.tbView];
}

- (void)downloadData{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSMutableDictionary *dict=[NSMutableDictionary dictionary];
    [dict setObject:@"3" forKey:@"type"];
    [dict setObject:self.textString forKey:@"keyword"];
    
    __weak SearchResultViewController *weakSelf = self;
   
    
    [manager POST:kSearchUrl parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
        id result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dict = result;
            NSDictionary *dataDict = dict[@"data"];
            for (NSDictionary *articleSearchsDict in dataDict[@"articleSearchs"]) {
                NewsModel *model = [[NewsModel alloc] init];
                model.title = articleSearchsDict[@"title"];
                model.source = articleSearchsDict[@"source"];
                model.hot = [articleSearchsDict[@"hot"] integerValue];
                model.fileurl = articleSearchsDict[@"fileurl"];
                [weakSelf.dataArray addObject:model];
            }
        }
        if (self.dataArray.count == 0) {
            UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"抱歉，没有找到相关信息,请更换关键字" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定",nil];
            [alertView show];
        }else{
            [weakSelf.tbView reloadData];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"%@",error);
    }];
}

#pragma mark - UITablView代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"searchCellId";
    SearchResultViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"SearchResultViewCell" owner:nil options:nil] lastObject];
    }
    NewsModel *model = self.dataArray[indexPath.row];
    cell.model = model;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NewsModel *model = self.dataArray[indexPath.row];
    DetailViewController *ctrl = [[DetailViewController alloc] init];
    ctrl.model = model;
    [self.navigationController pushViewController:ctrl animated:YES];
}

//重新实现父类点击搜索按钮事件
- (void)searchAction:(id)sender{
    [self.searchField resignFirstResponder];
    [self.searchBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    self.textString = self.searchField.text;
    [self downloadData];
}

//重新实现键盘回车事件
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self searchAction:self.searchBtn];
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
