//
//  ShopViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/17.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "ShopViewController.h"
#import "Masonry.h"
#import "AFHTTPRequestOperationManager.h"
#import "ShopModel.h"
#import "ShopCell.h"

#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;
#define kCellReuseId (@"cellId")
#define kUrl (@"http://interfacev5.vivame.cn/x1-interface-v5/json/goodslist.json?platform=android&installversion=5.6.6.3&channelno=BDSCA2320480100&mid=7c2f435b4eb9c9267addf21979bc88c4&uid=11092073&sid=8c9c5035-dcba-46cd-8270-4e50da17e1f2")

@interface ShopViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>

@property (nonatomic,strong)UIImageView *navView;
@property (nonatomic,strong)UICollectionView *collView;
@property (nonatomic,strong)NSMutableArray *dataArray;

@end

@implementation ShopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.dataArray = [NSMutableArray array];
    
    [self createNavView];
    [self createCollectionView];
    [self downloadData];
}


- (void)downloadData{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    __weak ShopViewController *weakSelf = self;
    [manager GET:kUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        id data = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if ([data isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dict = data;
            NSDictionary *dataDict = dict[@"data"];
            for (NSDictionary *notHaveDict in dataDict[@"notHaveGoods"]) {
                ShopModel *model = [[ShopModel alloc] init];
                [model setValuesForKeysWithDictionary:notHaveDict];
                if (model.type == 1) {
                    [weakSelf.dataArray addObject:model];
                }
                
            }
        }
        [weakSelf.collView reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"%@",error);
    }];
}

//自定制导航
- (void)createNavView{
    WS(ws);
    self.navView = [[UIImageView alloc] init];
    self.navView.userInteractionEnabled = YES;
    self.navView.image = [UIImage imageNamed:@"HeaderBackground"];
    [ws.view addSubview:ws.navView];
    [ws.navView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(0);
        make.width.equalTo(ws.view);
        make.height.mas_equalTo(200);
    }];
    
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setBackgroundImage:[UIImage imageNamed:@"back@2x"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    [ws.navView addSubview:leftBtn];
    [leftBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(ws.navView.mas_left).with.offset(10);
        make.width.mas_equalTo(20);
        make.top.mas_equalTo(30);
        make.height.mas_equalTo(30);
    }];
    
}


- (void)createCollectionView{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.sectionInset = UIEdgeInsetsMake(5, 5, 5, 5);
    layout.itemSize =CGSizeMake((self.view.bounds.size.width-20)/3.0f, 190);
    layout.minimumInteritemSpacing = 5;
    layout.minimumLineSpacing = 10;
    
    self.collView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 200, self.view.bounds.size.width, self.view.bounds.size.height-200) collectionViewLayout:layout];
    self.collView.backgroundColor = [UIColor whiteColor];
    self.collView.delegate = self;
    self.collView.dataSource = self;
    [self.collView registerNib:[UINib nibWithNibName:@"ShopCell" bundle:nil] forCellWithReuseIdentifier:kCellReuseId];
    [self.view addSubview:self.collView];
}

- (void)backAction:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark-UICollectionView代理
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    ShopCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kCellReuseId forIndexPath:indexPath];
    ShopModel *model = self.dataArray[indexPath.item];
//    cell.backgroundColor = [UIColor whiteColor];
    [cell configModel:model];
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
