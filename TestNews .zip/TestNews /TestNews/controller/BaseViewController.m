//
//  BaseViewController.m
//  TestNews
//
//  Created by qianfeng on 15/10/5.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "BaseViewController.h"
#import "Masonry.h"
#import "ActivityViewController.h"
#import "TaskViewController.h"
#import "MyViewController.h"
#import "BaseViewController.h"
#import "ShopViewController.h"
#import "SearchViewController.h"
#import "LoadViewController.h"


#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;

@interface BaseViewController ()

@property (nonatomic,strong)UIView *navView;
@property (nonatomic,strong)UIView *myView;
@property (nonatomic,strong)UIButton *btn;

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //设置导航透明度
//    self.navigationController.navigationBar.translucent =NO;
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBarHidden = YES;
    [self createNavView];
    [self createScrollView];
}


//自定制导航
- (void)createNavView{
    WS(ws);
    self.navView = [[UIView alloc] init];
    self.navView.backgroundColor = [UIColor blackColor];
    [ws.view addSubview:ws.navView];
    [ws.navView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(0);
        make.width.equalTo(ws.view);
        make.height.mas_equalTo(64);
    }];
}

////状态栏的显示
- (BOOL)prefersStatusBarHidden{
    return NO;
}

- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}






//导航上的scrollView
- (void)createScrollView{
    WS(ws);
    //左侧的头像按钮
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.tag = 4001;
    [leftBtn setBackgroundImage:[UIImage imageNamed:@"guestIcon"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(headerAction:) forControlEvents:UIControlEventTouchUpInside];
    [ws.navView addSubview:leftBtn];
    [leftBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(ws.navView.mas_left).with.offset(10);
        make.width.mas_equalTo(35);
        make.top.mas_equalTo(20);
        make.height.mas_equalTo(35);
    }];
    
    //右侧的搜索按钮
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightBtn setBackgroundImage:[[UIImage imageNamed:@"Discovery_fav_search@2x"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal] ;
    [rightBtn addTarget:self action:@selector(listAction:) forControlEvents:UIControlEventTouchUpInside];
    [ws.navView addSubview:rightBtn];
    [rightBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(ws.navView.mas_right).with.offset(-5);
        make.width.mas_equalTo(30);
        make.top.mas_equalTo(25);
        make.height.mas_equalTo(35);
    }];
    
    _scrollView = [[UIScrollView alloc] init];
    _scrollView.showsHorizontalScrollIndicator = NO;
    
    [self.navView addSubview:_scrollView];
    [_scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(20);
        make.left.equalTo(ws.navView.mas_left).with.offset(50);
        make.right.equalTo(ws.navView.mas_right).with.offset(-44);
        make.height.mas_equalTo(44);
    }];
}



- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:@"data"];
    UIImage *image = [UIImage imageWithData:data];
    UIButton *hBtn = (UIButton *)[self.view viewWithTag:4000];
    [hBtn setBackgroundImage:image forState:UIControlStateNormal];
    [hBtn addTarget:self action:@selector(loadAction:) forControlEvents:UIControlEventTouchUpInside];
    hBtn.layer.cornerRadius = 40;
    hBtn.layer.masksToBounds = YES;
    
    
    UIButton *btn = (UIButton *)[self.view viewWithTag:4001];
    [btn setBackgroundImage:image forState:UIControlStateNormal];
    btn.layer.cornerRadius = 20;
    btn.layer.masksToBounds = YES;
    
    UILabel *label = (UILabel *)[self.view viewWithTag:4002];
    label.text = [[NSUserDefaults standardUserDefaults] objectForKey:@"nameFeild"];
    
}
//头像的点击事件
- (void)headerAction:(id)sender{
    self.tabBarController.tabBar.hidden = YES;
    
    WS(ws);
    self.myView = [[UIView alloc] init];
    self.myView.backgroundColor = [UIColor whiteColor];
    [ws.view addSubview:self.myView];
    [self.myView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(20);
        make.left.equalTo(ws.view);
        make.width.mas_equalTo(260);
        make.height.equalTo(ws.view);
    }];
    
    UIImageView *backImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"myRedBackground"]];
    backImage.userInteractionEnabled = YES;
    [ws.myView addSubview:backImage];
    [backImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(ws.myView);
        make.right.equalTo(ws.myView);
        make.top.equalTo(ws.myView);
        make.height.mas_equalTo(200);
    }];
    
    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:@"data"];
    UIImage *image = [UIImage imageWithData:data];
    
    UIButton *hBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [backImage addSubview:hBtn];
    hBtn.tag = 4000;
    [hBtn setBackgroundImage:image forState:UIControlStateNormal];
    [hBtn addTarget:self action:@selector(loadAction:) forControlEvents:UIControlEventTouchUpInside];
    hBtn.layer.cornerRadius = 40;
    hBtn.layer.masksToBounds = YES;
    [hBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(90);
        make.top.mas_equalTo(60);
        make.width.mas_equalTo(80);
        make.height.mas_equalTo(80);
    }];
    
    UILabel *label = [[UILabel alloc] init];
    [backImage addSubview:label];
    label.tag = 4002;
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(65);
        make.top.equalTo(hBtn.mas_bottom).offset(-2);
        make.right.equalTo(backImage.mas_right).offset(-5);
        make.height.mas_equalTo(40);
    }];
    label.text = @"畅读网友11024477";
    
    
    NSArray *imageArray = @[@"shoppingIcon@3x",@"activityIcon@3x",@"taskIcon@3x",@"myDownIcon@3x"];
    NSArray *titleArray = @[@"道具商店",@"精彩活动",@"每日任务",@"我的收藏"];
    
    for (int i =0 ; i<4; i++) {
        
        int row = i/2;
        int low = i%2;
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setBackgroundImage:[UIImage imageNamed:@"colorbtnone_Normal@3x"] forState:UIControlStateNormal];
        [self.myView addSubview:btn];
        [btn addTarget:self action:@selector(clickAction:) forControlEvents:UIControlEventTouchUpInside];
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(backImage.mas_bottom).offset(160*row);
            make.left.mas_equalTo(ws.myView.mas_left).offset(120*low+20);
            make.width.mas_equalTo(100);
            make.height.mas_equalTo(100);
        }];
        
        btn.tag = 300+i;
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.image = [UIImage imageNamed:imageArray[i]];
        [btn addSubview:imageView];
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(btn);
            make.width.mas_equalTo(50);
            make.height.mas_equalTo(50);
        }];
//        imageView.userInteractionEnabled = YES;
        
        UILabel *label = [[UILabel alloc] init];
        label.text = titleArray[i];
        label.font = [UIFont systemFontOfSize:20];
        [ws.myView addSubview:label];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(btn.mas_bottom).offset(10);
            make.left.mas_equalTo(ws.myView.mas_left).offset(120*low+30);
            make.width.mas_equalTo(80);
            make.height.mas_equalTo(20);
        }];
        
    }
    
    self.btn = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.btn setBackgroundColor:[UIColor grayColor]];
    [self.btn addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    [ws.view addSubview:self.btn];
    [self.btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(20);
        make.left.equalTo(self.myView.mas_right);
        make.right.equalTo(ws.view);
        make.height.equalTo(ws.view);
    }];
    self.btn.alpha = 0.4;
}

- (void)loadAction:(UIButton *)btn{
    LoadViewController *lCtrl = [[LoadViewController alloc] init];
    [self.navigationController pushViewController:lCtrl animated:YES];
}


//下拉的事件
- (void)listAction:(id)sender{
    SearchViewController *ctrl = [[SearchViewController alloc] init];
    self.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:ctrl animated:YES];
    self.hidesBottomBarWhenPushed = NO;
}


//头像弹出按钮的事件
- (void)clickAction:(UIButton *)btn{
    if(btn.tag == 300){
        ShopViewController *ctrl = [[ShopViewController alloc] init];
        [self.navigationController pushViewController:ctrl animated:YES];
    }else if (btn.tag == 301) {
        ActivityViewController *ctrl = [[ActivityViewController alloc] init];
        [self.navigationController pushViewController:ctrl animated:YES];
    }else if (btn.tag == 302){
        TaskViewController *ctrl = [[TaskViewController alloc] init];
        [self.navigationController pushViewController:ctrl animated:YES];
    }else if (btn.tag == 303){
        MyViewController *ctrl = [[MyViewController alloc] init];
        
        [self.navigationController pushViewController:ctrl animated:YES];
    }}
    

//收回头像弹窗
- (void)back:(id)sender{
    self.tabBarController.tabBar.hidden =NO;
    [self.myView removeFromSuperview];
    [self.btn removeFromSuperview];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.hidden = NO;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
