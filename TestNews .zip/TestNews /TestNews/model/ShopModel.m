//
//  ShopModel.m
//  TestNews
//
//  Created by qianfeng on 15/10/18.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "ShopModel.h"

@implementation ShopModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}

@end
