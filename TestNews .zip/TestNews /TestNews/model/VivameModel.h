//
//  VivameModel.h
//  TestNews
//
//  Created by qianfeng on 15/10/9.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VivameModel : NSObject


@property (nonatomic,strong)NSString *content;
@property (nonatomic,strong)NSString *objectId;
@property (nonatomic,strong)NSString *objectTitle;

@property (nonatomic,strong)NSString *objectImg;
@property (nonatomic,strong)NSString *nickName;
@property (nonatomic,strong)NSString *headIcon;

@property (nonatomic,strong)NSString *title;
@property (nonatomic,assign)NSInteger likecount;
@property (nonatomic,assign)NSInteger objectType;



@end
/*

commentObject": {
"communityMessageId": "56178e2be4b054880e8d49f6",
"template": 139,
"objectType": 3,
"content": "珍惜我们拥有的和平",
"objectId": "1510091534104",
"objectTitle": "最可怕的城市：随时有人被杀死在街头",
"objectImg": "http://imagesv5.vivame.cn/pic/upload/phote/201510/5c989f95-3726-4f45-9926-6a8fc1278fc5.jpg",
"magId": 0,
"pageNum": 0,
"createTime": 1444384299712,
"issueTime": 1444384477282,
"status": 0,
"uid": 10612054,
"tagId": "-4"
},
"communityUser": {
    "uid": 10612054,
    "nickName": "阳光很浅&想念你的笑很暖",
    "lvl": 5,
    "headIcon": "http://staticv5.vivame.cn/spider/icons/20150902/ff4fce32-3474-4608-bcc1-392e8b667949.jpeg",
    "goods": [
              {
                  "id": 98,
                  "type": 2,
                  "img": "http://stcv5.vivame.cn/pmsV5/item/item/upload/file/20150828/0db64e46-d103-4419-8577-d9525f806c77.png"
              }
              ],
    "title": "时事达人",
    "status": 5
},
"likeInfo": {
    "likeCount": 2,
    "likeUserList": [
                     {
                         "uid": 385645,
                         "headIcon": "http://staticv5.vivame.cn/spider/icons/20150707/8261c5e2-4797-473c-a103-6b43232a3fa5.png",
                         "status": 2
                     },
                     {
                         "uid": 381829,
                         "headIcon": "http://staticv5.vivame.cn/spider/icons/20150517/65da85d7-954b-4e7f-9f53-1767e16fc85f.png",
                         "status": 3
                     }
                     ],
    "liked": false
},
"communityCommentInfo": {
    "commentCount": 0,
    "commentList": []
},
"seq": 0
},

*/