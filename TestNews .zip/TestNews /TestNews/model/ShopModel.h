//
//  ShopModel.h
//  TestNews
//
//  Created by qianfeng on 15/10/18.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShopModel : NSObject

@property (nonatomic,assign)NSInteger type;
@property (nonatomic,strong)NSString *name;
@property (nonatomic,assign)NSInteger price;

@property (nonatomic,strong)NSString *img;

/*"id": 128,
"type": 2,
"name": "青龙偃月刀",
"price": 550,
"salePrice": 0,
"img": "http://stcv5.vivame.cn/pmsV5/item/item/upload/file/20151016/374e4de3-0327-4d9f-9c2c-6e22c78a9ebc.png"*/

@end
