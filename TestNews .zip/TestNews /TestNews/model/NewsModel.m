//
//  NewsModel.m
//  TestNews
//
//  Created by qianfeng on 15/10/9.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "NewsModel.h"

@implementation NewsModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}

@end




