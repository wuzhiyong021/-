//
//  PhotoModel.h
//  TestNews
//
//  Created by qianfeng on 15/10/14.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PhotoModel : NSObject

@property (nonatomic,strong)NSString *title;
@property (nonatomic,strong)NSString *cover;
@property (nonatomic,strong)NSString *img;

@property (nonatomic,strong)NSString *desc;

@end
