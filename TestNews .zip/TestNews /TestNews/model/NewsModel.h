//
//  NewsModel.h
//  TestNews
//
//  Created by qianfeng on 15/10/9.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsModel : NSObject


@property (nonatomic,assign)NSInteger tId;
@property (nonatomic,assign)NSInteger stypeid;
@property (nonatomic,strong)NSString *stypename;

@property (nonatomic,assign)NSInteger action;
@property (nonatomic,strong)NSString *title;
@property (nonatomic,strong)NSString *subtitle;

@property (nonatomic,assign)NSInteger imgWidth;
@property (nonatomic,assign)NSInteger imgHeight;
@property (nonatomic,strong)NSString *img;

@property (nonatomic,strong)NSString *mimg;
@property (nonatomic,strong)NSString *bigimg;
@property (nonatomic,strong)NSString *url;

@property (nonatomic,strong)NSString *ext;
@property (nonatomic,strong)NSString *clickMonitor;
@property (nonatomic,strong)NSString *exposureMonitor;

@property (nonatomic,strong)NSString *desc;
@property (nonatomic,assign)NSInteger hot;
@property (nonatomic,assign)NSInteger time;

@property (nonatomic,strong)NSString *source;
@property (nonatomic,assign)NSInteger piccount;
@property (nonatomic,assign)NSInteger status;

@property (nonatomic,assign)NSInteger artificial;
@property (nonatomic,strong)NSString *seqDate;
@property (nonatomic,strong)NSString *channels;

@property (nonatomic,assign)NSInteger weight;
@property (nonatomic,assign)NSInteger seq;
@property (nonatomic,assign)NSInteger templet;

@property (nonatomic,assign)NSInteger isOptimize;
@property (nonatomic,strong)NSString *pm;
@property (nonatomic,strong)NSString *cm;

@property (nonatomic,strong)NSString *adPlatformId;
@property (nonatomic,assign)NSInteger endBannerType;
@property (nonatomic,strong)NSString *img02;

@property (nonatomic,strong)NSString *img03;
@property (nonatomic,strong)NSString *fileurl;
@property (nonatomic,assign)NSInteger subCount;

@end


