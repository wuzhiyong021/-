//
//  CommentModel.m
//  TestNews
//
//  Created by qianfeng on 15/10/24.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "CommentModel.h"

@implementation CommentModel

@end
