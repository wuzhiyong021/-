//
//  CommentModel.h
//  TestNews
//
//  Created by qianfeng on 15/10/24.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommentModel : NSObject

@property (nonatomic,strong)NSString *nickName;
@property (nonatomic,strong)NSString *content;

@end
