//
//  TaskModel.h
//  TestNews
//
//  Created by qianfeng on 15/10/17.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TaskModel : NSObject

@property (nonatomic,strong)NSString *title;
@property (nonatomic,assign)NSInteger awardCount;

@end
/*"id": 87,
"title": "关注8个频道",
"category": 1,
"actionType": 3,
"actionInfo": "",
"completeCondition": 8,
"completeCount": 0,
"awardCount": 12,
"status": 0,
"awardStatus": 0,
"priority": 0,
"seq": 0*/


