//
//  PhotoModel.m
//  TestNews
//
//  Created by qianfeng on 15/10/14.
//  Copyright (c) 2015年 wuzhiyong. All rights reserved.
//

#import "PhotoModel.h"

@implementation PhotoModel


- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
}
@end
